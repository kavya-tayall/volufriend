import 'package:equatable/equatable.dart';

/// This class defines the variables used in the [vf_loginaccountscreen_screen],
/// and is typically used to hold data that is passed between different parts of the application.
class VfLoginaccountscreenModel extends Equatable {
  VfLoginaccountscreenModel();

  VfLoginaccountscreenModel copyWith() {
    return VfLoginaccountscreenModel();
  }

  @override
  List<Object?> get props => [];
}
