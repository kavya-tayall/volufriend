import 'package:flutter/material.dart';
import 'package:equatable/equatable.dart';
import '../../../core/app_export.dart';
import '../../vf_homescreen_page/models/upcomingeventslist_item_model.dart';
import '../../vf_eventlist_screen/models/vf_eventlist_model.dart';
import '/crud_repository/volufriend_crud_repo.dart';

part 'vf_eventlist_event.dart';
part 'vf_eventlist_state.dart';

/// A bloc that manages the state of a VfHomescreen according to the event that is dispatched to it.
class EventListBloc
    extends Bloc<VfEventListScreenEvent, VfEventListScreenState> {
  final VolufriendCrudService vfcrudService;

  EventListBloc(VfEventListScreenState initialState, this.vfcrudService)
      : super(
          initialState,
        ) {
    on<EventListScreenInitialEvent>(_onInitialize);
    on<LoadUpcomingEventListEvent>(_onLoadUpcomingEventListEvent);
    on<LoadEventListForApprovalEvent>(
        _onLoadEventListForAttendanceApprovalEvent);
  }

  Future<void> _onInitialize(
    EventListScreenInitialEvent event,
    Emitter<VfEventListScreenState> emit,
  ) async {
    emit(state.copyWith(isLoading: true)); // Start loading state
    print(event.role);
    try {
      if (event.role == "Volunteer") {
        await _onLoadInterestedEvents(
            LoadUpcomingInterestEventListEvent(userId: event.userId), emit);
      } else if (event.role == "Organization" && event.listType == "Upcoming") {
        await _onLoadUpcomingEventListEvent(
            LoadUpcomingEventListEvent(userId: event.userId), emit);
      } else if (event.role == "Organization" && event.listType == "Approve") {
        await _onLoadEventListForAttendanceApprovalEvent(
            LoadEventListForApprovalEvent(userId: event.userId), emit);
      }

      emit(
        state.copyWith(
          ListType: event.listType,
          vfEventListModelObj:
              (state.vfEventListModelObj ?? VfEventListModel()).copyWith(
            upcomingeventslistItemList: fillUpcomingeventslistItemList(),
            // Ensure this is not null
          ),
          isLoading: false, // End loading state
        ),
      );
    } catch (error) {
      // Handle errors and update state with error message
      print('Error initializing state: $error');
      emit(state.copyWith(
        isLoading: false,
        errorMessage: 'Failed to initialize VfHomescreen state: $error',
      ));
    }
  }

  List<UpcomingeventslistItemModel> fillUpcomingeventslistItemList() {
    // Ensure upcomingEventsList is not null and contains data
    if (state.upcomingEventsList == null || state.upcomingEventsList!.isEmpty) {
      return []; // Return an empty list if there are no events
    }

    // Map each event to an UpcomingeventslistItemModel
    return state.upcomingEventsList!.map((event) {
      return UpcomingeventslistItemModel(
        id: event.eventId ?? "", // Use event.eventId
        listItemHeadlin:
            event.title, // Use event.title or provide default value
        listItemSupport:
            event.description, // Use event.description or provide default value
      );
    }).toList();
  }

  Future<void> _onLoadInterestedEvents(
    LoadUpcomingInterestEventListEvent event,
    Emitter<VfEventListScreenState> emit,
  ) async {
    emit(state.copyWith(isLoading: true));
    try {
      final List<Voluevents> upcomingEventsData =
          await vfcrudService.getUserInterestedEvents(event.userId!);

      // Convert the events to a list of maps for search
      final List<Map<String, String>> allEvents =
          convertEventsToMap(upcomingEventsData);

      // Emit the new state with the fetched events
      emit(state.copyWith(
        isLoading: false,
        upcomingEventsList: upcomingEventsData,
        allEvents: allEvents,
      ));
    } catch (error) {
      print('Error loading Interested events: $error');
      emit(state.copyWith(
        isLoading: false,
        upcomingEventsList: [], // Optionally reset or handle empty state
        errorMessage: 'Failed to load Interested events',
      ));
    }
  }

  List<Map<String, String>> convertEventsToMap(List<Voluevents> events) {
    return events.map((event) {
      return {
        'eventId': event.eventId,
        'cause': event.cause ?? 'Unknown', // Handle null cause
        'title': event.title ?? 'Unknown', // Handle null title
        'org_name': event.orgName ?? 'Unknown', // Handle null orgName
      };
    }).toList();
  }

  Future<void> _onLoadUpcomingEventListEvent(
    LoadUpcomingEventListEvent event,
    Emitter<VfEventListScreenState> emit, // Correct the type of Emitter
  ) async {
    print('Handling LoadUpcomingEventListEvent');
    emit(state.copyWith(isLoading: true)); // Indicate loading state

    try {
      // Fetch the upcoming events list from the service
      final List<Voluevents> upcomingEventsData =
          await vfcrudService.getUpcomingEventsforOrgUser(event.userId!);

      // Convert the events to a list of maps for search
      final List<Map<String, String>> allEvents =
          convertEventsToMap(upcomingEventsData);
      print('allevents: $allEvents');
      // Emit the new state with the fetched events
      emit(state.copyWith(
        isLoading: false,
        upcomingEventsList: upcomingEventsData,
        allEvents: allEvents,
      ));
    } catch (error) {
      print('Error loading upcoming events: $error');
      emit(state.copyWith(
        isLoading: false,
        upcomingEventsList: [], // Optionally reset or handle empty state
        errorMessage: 'Failed to load upcoming events',
      ));
    }
  }

  Future<void> _onLoadEventListForAttendanceApprovalEvent(
    LoadEventListForApprovalEvent event,
    Emitter<VfEventListScreenState> emit, // Correct the type of Emitter
  ) async {
    print('Handling _onLoadEventListForAttendanceApprovalEvent');
    emit(state.copyWith(isLoading: true)); // Indicate loading state

    try {
      // Fetch the upcoming events list from the service
      final List<Voluevents> upcomingEventsData =
          await vfcrudService.geteventandshiftforapproval(event.userId!);

      // Convert the events to a list of maps for search
      final List<Map<String, String>> allEvents =
          convertEventsToMap(upcomingEventsData);
      print('events for approval: $allEvents');
      // Emit the new state with the fetched events
      emit(state.copyWith(
        isLoading: false,
        upcomingEventsList: upcomingEventsData,
        allEvents: allEvents,
      ));
    } catch (error) {
      print('Error loading events for approval: $error');
      emit(state.copyWith(
        isLoading: false,
        upcomingEventsList: [], // Optionally reset or handle empty state
        errorMessage: 'Failed to load events for approval',
      ));
    }
  }
}
