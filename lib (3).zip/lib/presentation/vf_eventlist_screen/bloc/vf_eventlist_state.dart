part of 'vf_eventlist_bloc.dart';

/// Represents the state of VfHomescreen in the application.
class VfEventListScreenState extends Equatable {
  final VfEventListModel? vfEventListModelObj;
  final bool isLoading; // To manage loading state
  final List<Voluevents>? upcomingEventsList;
  final String? errorMessage; // Added field for error messages
  final List<Map<String, String>> allEvents;
  final String ListType;

  const VfEventListScreenState({
    this.vfEventListModelObj,
    this.isLoading = false,
    this.upcomingEventsList,
    this.errorMessage, // Initialize errorMessage
    this.allEvents = const [],
    this.ListType = "",
  });

  @override
  List<Object?> get props => [
        vfEventListModelObj,
        isLoading,
        upcomingEventsList,
        errorMessage, // Add to props for equality checks
        allEvents,
        ListType,
      ];

  VfEventListScreenState copyWith({
    VfEventListModel? vfEventListModelObj,
    bool? isLoading,
    List<Voluevents>? upcomingEventsList,
    String? errorMessage, // Added parameter for errorMessage
    List<Map<String, String>>? allEvents,
    String? ListType,
  }) {
    return VfEventListScreenState(
      vfEventListModelObj: vfEventListModelObj ?? this.vfEventListModelObj,
      isLoading: isLoading ?? this.isLoading,
      upcomingEventsList: upcomingEventsList ?? this.upcomingEventsList,
      errorMessage: errorMessage ?? this.errorMessage, // Handle errorMessage
      allEvents: allEvents ?? this.allEvents,
      ListType: ListType ?? this.ListType,
    );
  }
}
