// event_search_state.dart
class EventSearchState {
  final List<Map<String, String>> filteredEvents;

  EventSearchState({this.filteredEvents = const []});
}
