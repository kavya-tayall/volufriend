import 'package:equatable/equatable.dart';

/// This class defines the variables used in the [vf_onboarding_2_screen],
/// and is typically used to hold data that is passed between different parts of the application.
class VfOnboarding2Model extends Equatable {
  VfOnboarding2Model();

  VfOnboarding2Model copyWith() {
    return VfOnboarding2Model();
  }

  @override
  List<Object?> get props => [];
}
