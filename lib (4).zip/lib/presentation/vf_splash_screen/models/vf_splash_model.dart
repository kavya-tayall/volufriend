import 'package:equatable/equatable.dart';

/// This class defines the variables used in the [vf_splash_screen],
/// and is typically used to hold data that is passed between different parts of the application.
class VfSplashModel extends Equatable {
  VfSplashModel();

  VfSplashModel copyWith() {
    return VfSplashModel();
  }

  @override
  List<Object?> get props => [];
}
