import 'package:flutter/material.dart';
import 'package:dotted_border/dotted_border.dart';
import 'package:flutter_bloc/flutter_bloc.dart'; // Added import
import 'package:volufriend/auth/bloc/org_event_bloc.dart';
import 'package:volufriend/crud/crud.dart';
import '../../core/app_export.dart';
import '../../widgets/custom_icon_button.dart';
import 'bloc/vf_homescreen_bloc.dart';
import 'models/actionbuttons_item_model.dart';
import 'models/upcomingeventslist_item_model.dart';
import 'models/vf_homescreen_model.dart';
import 'widgets/actionbuttons_item_widget.dart';
import 'widgets/upcomingeventslist_item_widget.dart';
import 'widgets/volunteergoalhours_graph_widget.dart';
import 'widgets/vf_searchscreen_page.dart';
import 'widgets/todayevent_item_widget.dart';
import '/crud_repository/volufriend_crud_repo.dart';
import '../../auth/bloc/login_user_bloc.dart';
import '../vf_homescreen_container_screen/bloc/vf_homescreen_container_bloc.dart';
import 'package:volufriend/presentation/vf_createeventscreen2_eventshifts_screen/bloc/vf_createeventscreen2_eventshifts_bloc.dart';
import 'package:volufriend/presentation/vf_createeventscreen1_eventdetails_screen/bloc/vf_createeventscreen1_eventdetails_bloc.dart';
import 'package:volufriend/presentation/vf_createeventscreen3_eventadditionaldetails_screen/bloc/vf_createeventscreen3_eventadditionaldetails_bloc.dart';

class VfHomescreenPage extends StatelessWidget {
  const VfHomescreenPage({Key? key}) : super(key: key);

  static Widget builder(BuildContext context) {
    final String userRole = getUserRole(context);
    final String userId = getUserId(context);
    final String orgUserId = getOrgUserId(context);
    final String userIdorOrgUserId =
        userRole == 'Volunteer' ? userId : orgUserId;

    context.read<VfHomescreenBloc>().add(
        VfHomescreenInitialEvent(userId: userIdorOrgUserId, role: userRole));
    context.read<orgVoluEventBloc>().add(resetEvent());
    return const VfHomescreenPage();
  }

  @override
  Widget build(BuildContext context) {
    final String userRole = getUserRole(context);

    Voluevents fetchTodayEvent() {
      return Voluevents(
        eventId: 'event123',
        orgUserId: 'orgUser456',
        address: '123 Main St, Springfield',
        causeId: 'cause789',
        coordinator: Coordinator(
          name: 'John Doe',
          email: "abc@gmail.com",
          phone: '123-456-7890',
        ),
        createdAt: DateTime.now().subtract(Duration(days: 10)),
        createdBy: 'admin',
        description: 'A community event to help clean the park.',
        endDate: DateTime.now().add(Duration(days: 1)),
        eventAlbum: 'album123',
        eventStatus: 'Active',
        eventWebsite: 'https://example.com/event',
        location: 'Springfield Park',
        title: 'Park Cleanup',
        orgId: 'org123',
        startDate: DateTime.now(),
        regByDate: DateTime.now().subtract(Duration(days: 1)),
        updatedAt: DateTime.now(),
        updatedBy: 'admin',
        EventHostingType: ['In-Person'],
        orgName: 'Springfield Volunteers',
        shifts: [
          Shift(
            shiftId: 'shift123',
            eventId: 'event123',
            activity: 'Morning Shift',
            startTime: DateTime.now(),
            endTime: DateTime.now().add(Duration(hours: 4)),
            maxNumberOfParticipants: 10,
          ),
        ],
      );
    }

    final Voluevents todayEvent = fetchTodayEvent();

    return Scaffold(
      backgroundColor: Colors.white,
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              SizedBox(height: 24),

              // Search Bar - Applicable for both roles
              GestureDetector(
                onTap: () {
                  showModalBottomSheet(
                    context: context,
                    isScrollControlled: true,
                    backgroundColor: Colors.transparent,
                    builder: (context) => SearchPage(
                      socialCauses: [],
                      allEvents: BlocProvider.of<VfHomescreenBloc>(context)
                          .state
                          .allEvents,
                      onEventTap: (event) {
                        print("Tapped event: ${event['name']}");
                        Navigator.pop(context);
                      },
                    ),
                  );
                },
                child: Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    border: Border.all(color: Colors.grey.shade300),
                    borderRadius: BorderRadius.circular(12),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.grey.withOpacity(0.2),
                        spreadRadius: 2,
                        blurRadius: 6,
                        offset: Offset(0, 3),
                      ),
                    ],
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        "Search events, causes, organizations...",
                        style: TextStyle(
                            color: Colors.grey.shade600, fontSize: 16),
                      ),
                      Icon(Icons.search, color: Colors.grey.shade600),
                    ],
                  ),
                ),
              ),
              SizedBox(height: 20),

              // Today's Event
              if (todayEvent != null) TodayEventWidget(event: todayEvent),
              SizedBox(height: 20),

              // Organization-Specific Content
              if (userRole == 'Organization')
                _buildOrganizationHomeContent(context),

              // Volunteer-Specific Content
              if (userRole == 'Volunteer') _buildVolunteerHomeContent(context),
            ],
          ),
        ),
      ),
    );
  }

// Organization Home Content - No GoalProgressWidget
  Widget _buildOrganizationHomeContent(BuildContext context) {
    return Container(
      width: double.infinity,
      decoration: BoxDecoration(
        color: Colors.blueGrey.shade50,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: Colors.grey.withOpacity(0.1),
            spreadRadius: 1,
            blurRadius: 5,
            offset: Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  "Upcoming Events",
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: Colors.grey.shade900,
                  ),
                ),
                SizedBox(height: 16),
              ],
            ),
          ),

          // Organization Upcoming Events
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16.0),
            child: _buildOrgUpcomingEventsList(context),
          ),
          SizedBox(height: 16),

          // "Show All" Button for Organization
          Align(
            alignment: Alignment.centerRight,
            child: Padding(
              padding: const EdgeInsets.only(right: 16.0),
              child: GestureDetector(
                onTap: () {
                  final String userRole = getUserRole(context);
                  if (userRole == 'Organization') {
                    context
                        .read<orgVoluEventBloc>()
                        .add(showallorgeventsEvent());
                  } else {
                    context
                        .read<orgVoluEventBloc>()
                        .add(showallusereventsEvent());
                  }

                  NavigatorService.pushNamed(AppRoutes.vfEventListScreen);
                },
                child: Text(
                  "Show All",
                  style: TextStyle(
                    fontSize: 16,
                    color: Colors.blue,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
            ),
          ),
          SizedBox(height: 32),

          // Action Buttons for Organization
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16.0),
            child: _buildActionButtonsForOrgProfile(context),
          ),
          SizedBox(height: 40),
        ],
      ),
    );
  }

// Volunteer Home Content - Includes GoalProgressWidget
  Widget _buildVolunteerHomeContent(BuildContext context) {
    return Container(
      width: double.infinity,
      decoration: BoxDecoration(
        color: Colors.blueGrey.shade50,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: Colors.grey.withOpacity(0.1),
            spreadRadius: 1,
            blurRadius: 5,
            offset: Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Show GoalProgressWidget only for volunteers
                GoalProgressWidget(completedHours: 100, goalHours: 500),
                SizedBox(height: 24),
                Text(
                  "Events you might be interested in",
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: Colors.grey.shade900,
                  ),
                ),
                SizedBox(height: 16),
              ],
            ),
          ),

          // Volunteer Interested Events
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16.0),
            child: _buildVolunteerIntrestedEvents(context),
          ),
          SizedBox(height: 16),

          // "Show All" Button
          Align(
            alignment: Alignment.centerRight,
            child: Padding(
              padding: const EdgeInsets.only(right: 16.0),
              child: GestureDetector(
                onTap: () {
                  context.read<orgVoluEventBloc>().add(attendanceReportEvent());
                  NavigatorService.pushNamed(AppRoutes.vfEventListScreen);
                },
                child: Text(
                  "Show All",
                  style: TextStyle(
                    fontSize: 16,
                    color: Colors.blue,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
            ),
          ),
          SizedBox(height: 32),

          // Action Buttons for Volunteers
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16.0),
            child: _buildActionButtonsForVolunteer(context),
          ),
          SizedBox(height: 40),
        ],
      ),
    );
  }

// Helper method to get user role
  static String getUserRole(BuildContext context) {
    // Access the bloc for user role
    final userBloc = BlocProvider.of<UserBloc>(context);
    final userState = userBloc.state;

    if (userState is LoginUserWithHomeOrg) {
      return userState.user.userHomeOrg?.role == "Volunteer"
          ? "Volunteer"
          : "Organization";
    }
    return "";
  }

  static String getUserId(BuildContext context) {
    // Access the bloc for user role

    final userBloc = BlocProvider.of<UserBloc>(context);
    final userState = userBloc.state;
    final userId = userState.userId ?? '';
    return userId;
  }

  static String getOrgUserId(BuildContext context) {
    // Access the bloc for user role

    final userBloc = BlocProvider.of<UserBloc>(context);
    final userState = userBloc.state;
    if (userState is LoginUserWithHomeOrg) {
      print('User is logged in with home org');
      final userHomeOrg = userState.user.userHomeOrg;
      return userHomeOrg?.useridinorg ?? '';
    }
    return '';
  }

// Define the Volunteer button builder
  Widget _buildActionButtonsForVolunteer(BuildContext context) {
    return SizedBox(
      height: 100.h,
      width: 356.h,
      child: BlocListener<orgVoluEventBloc, orgVoluEventState>(
        listener: (context, state) {
          // Handle state changes if needed
          print("I am called");
          if (state.scheduledEvents) {
            // Navigate to VfCreateeventscreen1EventdetailsScreen
            print('Navigating to vfMyupcomingeventscreenScreen ');
            NavigatorService.pushNamed(AppRoutes.vfMyupcomingeventscreenScreen);
          } else if (state.volunteerProfile) {
            // Navigate to VfCreateeventscreen1EventdetailsScreen
            print('Navigating to vfViewvolunteeringprofilescreenScreen');
            NavigatorService.pushNamed(
                AppRoutes.vfViewvolunteeringprofilescreenScreen);
          } else if (state.attendanceReport) {
            // Navigate to VfCreateeventscreen1EventdetailsScreen
            print('Navigating to vfUserattendancereportpageScreen');
            NavigatorService.pushNamed(
                AppRoutes.vfuserattendancereportpageScreen);
          }
        },
        child: BlocSelector<VfHomescreenBloc, VfHomescreenState,
            VfHomescreenModel?>(
          selector: (state) => state.vfHomescreenModelObj,
          builder: (context, vfHomescreenModelObj) {
            if (vfHomescreenModelObj?.actionbuttonsItemList == null ||
                vfHomescreenModelObj!.actionbuttonsItemList.isEmpty) {
              return Center(
                child: Text('No action buttons available'),
              );
            }
            return ListView.separated(
              padding: EdgeInsets.only(
                left: 20.h,
                right: 30.h,
              ),
              scrollDirection: Axis.horizontal,
              separatorBuilder: (context, index) {
                return SizedBox(
                  width: 42.h,
                );
              },
              itemCount: vfHomescreenModelObj.actionbuttonsItemList.length,
              itemBuilder: (context, index) {
                ActionbuttonsItemModel model =
                    vfHomescreenModelObj.actionbuttonsItemList[index];
                return ActionbuttonsItemWidget(model, onPressed: () {
                  print('Tapped on: ${model.text}');
                  if (model.text == 'New opportunities') {
                    // Navigate to VfCreateeventscreen1EventdetailsScreen
                    context
                        .read<orgVoluEventBloc>()
                        .add(findNewOpportunitiesEvent());
                  } else if (model.text == 'View report') {
                    context
                        .read<orgVoluEventBloc>()
                        .add(attendanceReportEvent());
                  } else if (model.text == 'My events') {
                    context
                        .read<orgVoluEventBloc>()
                        .add(scheduledEventsEvent());
                  } else if (model.text == 'Volunteering profile') {
                    final userBloc = BlocProvider.of<UserBloc>(context);
                    final userState = userBloc.state;

                    if (userState is LoginUserWithHomeOrg) {
                      print('User is logged in with home org');
                      final userId = userState.userId!;
                      context
                          .read<orgVoluEventBloc>()
                          .add(volunteerProfileEvent(userId));
                    } else {
                      print('User is not logged in with home org');
                    }
                  } else {
                    // You can add different navigation logic for other buttons here if needed
                  }
                });
              },
            );
          },
        ),
      ),
    );
  }

  Widget _buildVolunteerIntrestedEvents(BuildContext context) {
    return BlocSelector<VfHomescreenBloc, VfHomescreenState,
        VfHomescreenModel?>(
      selector: (state) => state.vfHomescreenModelObj,
      builder: (context, vfHomescreenModelObj) {
        return ListView.builder(
          padding: EdgeInsets.zero,
          physics: const NeverScrollableScrollPhysics(),
          shrinkWrap: true,
          itemCount:
              (vfHomescreenModelObj?.upcomingeventslistItemList.length ?? 0) > 3
                  ? 3
                  : vfHomescreenModelObj?.upcomingeventslistItemList.length ??
                      0,
          itemBuilder: (context, index) {
            UpcomingeventslistItemModel model =
                vfHomescreenModelObj?.upcomingeventslistItemList[index] ??
                    UpcomingeventslistItemModel();
            return UpcomingeventslistItemWidget(
              upcomingeventslistItemModelObj: model,
              onTap: () {
                // Handle on tap action here
                resetEventInitializationFlags(context);

                print('Tapped on: ${model.id}');

                context.read<VfHomescreenBloc>().add(
                      UpcomingEventTappedEvent(eventId: model.id!),
                    );

                final upcomingEventsList =
                    BlocProvider.of<VfHomescreenBloc>(context)
                        .state
                        .upcomingEventsList;

                final selectedEvent = upcomingEventsList != null
                    ? upcomingEventsList
                        .firstWhere((element) => element.eventId == model.id)
                    : null;

                context
                    .read<orgVoluEventBloc>()
                    .add(UpdateEvent(model.id!, selectedEvent!));

                final orgEventBloc =
                    BlocProvider.of<VfHomescreenContainerBloc>(context);
                final orgEventState = orgEventBloc.state;
                final eventId = orgEventState.eventId;
                print('Event ID at the time of emmiting: $eventId');

                final orgEventBlocNew =
                    BlocProvider.of<orgVoluEventBloc>(context);
                final orgEventStateNew = orgEventBlocNew.state;
                final eventIdNew = orgEventStateNew.eventId;
                print('New bloc Event ID at the time of emmiting: $eventIdNew');

                NavigatorService.pushNamed(AppRoutes.vfEventsignupscreenScreen);
              },
              onLongPress: () {
                // Handle on long press action here
                print('Long pressed on: ${model.id}');
                // Add long press event handling logic, such as showing a dialog
              },
              onDismissed: () {
                // Handle on swipe action here
                print('Dismissed event: ${model.id}');
                context.read<VfHomescreenBloc>().add(
                      UpcomingEventDismissedEvent(eventId: model.id!),
                    );
              },
              onMenuSelected: (String action, String id) {
                // Handle the selected menu action and use the ID
                if (action == 'edit') {
                  print('Edit action selected for ID: $id');
                  // Perform edit action with the given ID
                } else if (action == 'delete') {
                  print('Delete action selected for ID: $id');
                  // Perform delete action with the given ID
                }
              },
            );
          },
        );
      },
    );
  }

  /// Section Widget
  Widget _buildOrgUpcomingEventsList(BuildContext context) {
    return BlocListener<orgVoluEventBloc, orgVoluEventState>(
      listener: (context, state) {
        // Listen for specific state changes or side effects if needed
        if (state.eventDetails) {
          // Navigate to VfCreateeventscreen1EventdetailsScreen
          print('Navigating to vfEventdetailspageScreen');
          NavigatorService.pushNamed(AppRoutes.vfEventdetailspageScreen);
        } else if (state.updateEvent) {
          // Navigate to VfCreateeventscreen1EventdetailsScreen
          print('Navigating to vfCreateeventscreen1EventdetailsScreen');
          resetEventInitializationFlags(context);
          NavigatorService.pushNamed(
              AppRoutes.vfCreateeventscreen1EventdetailsScreen);
        }
      },
      child:
          BlocSelector<VfHomescreenBloc, VfHomescreenState, VfHomescreenModel?>(
        selector: (state) => state.vfHomescreenModelObj,
        builder: (context, vfHomescreenModelObj) {
          return ListView.builder(
            padding: EdgeInsets.zero,
            physics: const NeverScrollableScrollPhysics(),
            shrinkWrap: true,
            itemCount:
                (vfHomescreenModelObj?.upcomingeventslistItemList.length ?? 0) >
                        3
                    ? 3
                    : vfHomescreenModelObj?.upcomingeventslistItemList.length ??
                        0,
            itemBuilder: (context, index) {
              UpcomingeventslistItemModel model =
                  vfHomescreenModelObj?.upcomingeventslistItemList[index] ??
                      UpcomingeventslistItemModel();
              return UpcomingeventslistItemWidget(
                upcomingeventslistItemModelObj: model,
                onTap: () {
                  // Get the selected event
                  final upcomingEventsList =
                      BlocProvider.of<VfHomescreenBloc>(context)
                          .state
                          .upcomingEventsList;
                  final selectedEvent = upcomingEventsList != null
                      ? upcomingEventsList
                          .firstWhere((element) => element.eventId == model.id)
                      : null;

                  if (selectedEvent != null) {
                    context.read<orgVoluEventBloc>().add(
                          eventdetailsEvent(model.id!, selectedEvent),
                        );
                  }

                  /*
                  // Handle on tap action
                  resetEventInitializationFlags(context);

                  print('Tapped on: ${model.id}');

                  // Trigger the events to update the Bloc states
                  context.read<VfHomescreenBloc>().add(
                        UpcomingEventTappedEvent(eventId: model.id!),
                      );
                  context
                      .read<VfHomescreenContainerBloc>()
                      .add(SetEventIdInDetailsViewMode(model.id!));

                  // Trigger another event in a different Bloc
                  context
                      .read<orgVoluEventBloc>()
                      .add(UpdateEvent(model.id!, selectedEvent));

                  // Navigate to the details screen
                  NavigatorService.pushNamed(
                      AppRoutes.vfCreateeventscreen1EventdetailsScreen);*/
                },
                onLongPress: () {
                  // Handle on long press action
                  print('Long pressed on: ${model.id}');
                  // You could show a dialog or additional options here
                },
                onDismissed: () {
                  // Handle swipe action (dismiss)
                  print('Dismissed event: ${model.id}');
                  context.read<VfHomescreenBloc>().add(
                        UpcomingEventDismissedEvent(eventId: model.id!),
                      );
                },
                onMenuSelected: (String action, String id) {
                  // Handle the selected menu action and use the ID
                  if (action == 'edit') {
                    print('Edit action selected for ID: $id');

                    // Get the selected event
                    final upcomingEventsList =
                        BlocProvider.of<VfHomescreenBloc>(context)
                            .state
                            .upcomingEventsList;
                    final selectedEvent = upcomingEventsList != null
                        ? upcomingEventsList.firstWhere(
                            (element) => element.eventId == model.id)
                        : null;

                    if (selectedEvent != null) {
                      context
                          .read<orgVoluEventBloc>()
                          .add(UpdateEvent(model.id!, selectedEvent));
                    }
                    // Perform edit action with the given ID
                  } else if (action == 'delete') {
                    print('Delete action selected for ID: $id');
                    // Perform delete action with the given ID
                  }
                },
              );
            },
          );
        },
      ),
    );
  }

  void resetEventInitializationFlags(BuildContext context) {
    // Access the bloc for VfCreateeventscreen1EventdetailsBloc
    print('Resetting event initialization flags');
    final eventDetailsBloc1 =
        BlocProvider.of<VfCreateeventscreen1EventdetailsBloc>(context);
    // Emit state with isInitialized set to false
    eventDetailsBloc1
        .add(VfCreateeventscreen1EventdetailsResetInitializationEvent());

    // Access the bloc for VfCreateeventscreen2EventdetailsBloc
    final eventDetailsBloc2 =
        BlocProvider.of<VfCreateeventscreen2EventshiftsBloc>(context);
    // Emit state with isInitialized set to false
    eventDetailsBloc2.add(VfCreateeventscreen2ShiftsResetInitializationEvent());

    // Access the bloc for VfCreateeventscreen3EventadditionaldetailsBloc
    final eventDetailsBloc3 =
        BlocProvider.of<VfCreateeventscreen3EventadditionaldetailsBloc>(
            context);
    // Emit state with isInitialized set to false
    eventDetailsBloc3.add(
        VfCreateeventscreen3EventadditionaldetailsResetInitializationEvent());
  }

  /// Section Widget
  Widget _buildActionButtonsForOrgProfile(BuildContext context) {
    return SizedBox(
      height: 100.h,
      width: 356.h,
      child: BlocListener<orgVoluEventBloc, orgVoluEventState>(
        listener: (context, state) {
          // Handle state changes if needed
          print("I am called");
          if (state.isLoading) {
            resetEventInitializationFlags(context);
            // Navigate to VfCreateeventscreen1EventdetailsScreen
            print(
                'Navigating to VfCreateeventscreen1EventdetailsScreen for create');
            NavigatorService.pushNamed(
                AppRoutes.vfCreateeventscreen1EventdetailsScreen);
          } else if (state.orgschedule) {
            // Navigate to VfCreateeventscreen1EventdetailsScreen
            print('Navigating to vfOrgschedulescreenScreen');
            NavigatorService.pushNamed(AppRoutes.vfOrgschedulescreenScreen);
          } else if (state.approvehours) {
            // Navigate to VfCreateeventscreen1EventdetailsScreen
            print(
                'Navigating to event list to perform vfApprovehoursscreenScreen');
            NavigatorService.pushNamed(AppRoutes.vfEventListScreen);
          } else if (state.manageEvents) {
            print('Navigating to event list to perform vfEventsearchScreen');
            NavigatorService.pushNamed(AppRoutes.vfEventsearchScreen);
          }
        },
        child: BlocSelector<VfHomescreenBloc, VfHomescreenState,
            VfHomescreenModel?>(
          selector: (state) => state.vfHomescreenModelObj,
          builder: (context, vfHomescreenModelObj) {
            if (vfHomescreenModelObj?.actionbuttonsItemList == null ||
                vfHomescreenModelObj!.actionbuttonsItemList.isEmpty) {
              return Center(
                child: Text('No action buttons available'),
              );
            }
            return ListView.separated(
              padding: EdgeInsets.only(
                left: 20.h,
                right: 30.h,
              ),
              scrollDirection: Axis.horizontal,
              separatorBuilder: (context, index) {
                return SizedBox(
                  width: 42.h,
                );
              },
              itemCount: vfHomescreenModelObj.actionbuttonsItemList.length,
              itemBuilder: (context, index) {
                ActionbuttonsItemModel model =
                    vfHomescreenModelObj.actionbuttonsItemList[index];
                return ActionbuttonsItemWidget(model, onPressed: () {
                  print('Tapped on: ${model.text}');
                  if (model.text == 'Create Event') {
                    // Navigate to VfCreateeventscreen1EventdetailsScreen
                    context.read<orgVoluEventBloc>().add(CreateEvent());
                  } else if (model.text == 'Approve Hours') {
                    // You can add different navigation logic for other buttons here if needed
                    context.read<orgVoluEventBloc>().add(approvehoursEvent(
                        "j", "j", "j", Voluevents(eventId: '')));
                  } else if (model.text == "Manage Events") {
                    context.read<orgVoluEventBloc>().add(manageEventsEvent());
                  }
                });
              },
            );
          },
        ),
      ),
    );
  }
}
