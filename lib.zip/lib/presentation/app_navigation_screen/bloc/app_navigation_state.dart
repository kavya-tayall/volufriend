part of 'app_navigation_bloc.dart';

/// Represents the state of AppNavigation in the application.
class AppNavigationState extends Equatable {
  final AppNavigationModel? appNavigationModelObj;
  final String? sourceScreen; // Add this field if it is used

  AppNavigationState({this.appNavigationModelObj, this.sourceScreen});

  @override
  List<Object?> get props => [appNavigationModelObj, sourceScreen];

  AppNavigationState copyWith({
    AppNavigationModel? appNavigationModelObj,
    String? sourceScreen,
  }) {
    return AppNavigationState(
      appNavigationModelObj:
          appNavigationModelObj ?? this.appNavigationModelObj,
      sourceScreen: sourceScreen ?? this.sourceScreen,
    );
  }
}
