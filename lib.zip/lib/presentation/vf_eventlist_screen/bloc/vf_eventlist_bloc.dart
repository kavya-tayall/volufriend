import 'package:flutter/material.dart';
import 'package:equatable/equatable.dart';
import '../../../core/app_export.dart';
import '../../vf_homescreen_page/models/upcomingeventslist_item_model.dart';
import '../../vf_eventlist_screen/models/vf_eventlist_model.dart';
import '/crud_repository/volufriend_crud_repo.dart';

part 'vf_eventlist_event.dart';
part 'vf_eventlist_state.dart';

/// A bloc that manages the state of a VfHomescreen according to the event that is dispatched to it.
class EventListBloc
    extends Bloc<VfEventListScreenEvent, VfEventListScreenState> {
  final VolufriendCrudService vfcrudService;

  EventListBloc(VfEventListScreenState initialState, this.vfcrudService)
      : super(
          initialState,
        ) {
    on<EventListScreenInitialEvent>(_onInitialize);
    on<LoadUpcomingEventListEvent>(_onLoadUpcomingEventListEvent);
  }

  Future<void> _onInitialize(
    EventListScreenInitialEvent event,
    Emitter<VfEventListScreenState> emit,
  ) async {
    emit(state.copyWith(isLoading: true)); // Start loading state

    try {
      if (event.role == "Volunteer") {
        await _onLoadInterestedEvents(
            LoadUpcomingInterestEventListEvent(userId: event.userId), emit);
      } else {
        await _onLoadUpcomingEventListEvent(LoadUpcomingEventListEvent(), emit);
      }

      emit(
        state.copyWith(
          vfEventListModelObj:
              (state.vfEventListModelObj ?? VfEventListModel()).copyWith(
            upcomingeventslistItemList:
                fillUpcomingeventslistItemList(), // Ensure this is not null
          ),
          isLoading: false, // End loading state
        ),
      );
    } catch (error) {
      // Handle errors and update state with error message
      print('Error initializing state: $error');
      emit(state.copyWith(
        isLoading: false,
        errorMessage: 'Failed to initialize VfHomescreen state: $error',
      ));
    }
  }

  List<UpcomingeventslistItemModel> fillUpcomingeventslistItemList() {
    // Ensure upcomingEventsList is not null and contains data
    if (state.upcomingEventsList == null || state.upcomingEventsList!.isEmpty) {
      return []; // Return an empty list if there are no events
    }

    // Map each event to an UpcomingeventslistItemModel
    return state.upcomingEventsList!.map((event) {
      return UpcomingeventslistItemModel(
        id: event.eventId ?? "", // Use event.eventId
        listItemHeadlin:
            event.title, // Use event.title or provide default value
        listItemSupport:
            event.description, // Use event.description or provide default value
      );
    }).toList();
  }

  Future<void> _onLoadInterestedEvents(
    LoadUpcomingInterestEventListEvent event,
    Emitter<VfEventListScreenState> emit,
  ) async {
    emit(state.copyWith(isLoading: true));
    try {
      final List<Voluevents> upcomingEventsData =
          await vfcrudService.getUserInterestedEvents(event.userId!);
      // Emit the new state with the fetched events
      emit(state.copyWith(
        isLoading: false,
        upcomingEventsList: upcomingEventsData,
      ));
    } catch (error) {
      print('Error loading Interested events: $error');
      emit(state.copyWith(
        isLoading: false,
        upcomingEventsList: [], // Optionally reset or handle empty state
        errorMessage: 'Failed to load Interested events',
      ));
    }
  }

  Future<void> _onLoadUpcomingEventListEvent(
    LoadUpcomingEventListEvent event,
    Emitter<VfEventListScreenState> emit, // Correct the type of Emitter
  ) async {
    print('Handling LoadUpcomingEventListEvent');
    emit(state.copyWith(isLoading: true)); // Indicate loading state

    try {
      // Fetch the upcoming events list from the service
      final List<Voluevents> upcomingEventsData =
          await vfcrudService.getEventsListWithShifts();

      // Emit the new state with the fetched events
      emit(state.copyWith(
        isLoading: false,
        upcomingEventsList: upcomingEventsData,
      ));
    } catch (error) {
      print('Error loading upcoming events: $error');
      emit(state.copyWith(
        isLoading: false,
        upcomingEventsList: [], // Optionally reset or handle empty state
        errorMessage: 'Failed to load upcoming events',
      ));
    }
  }
}
