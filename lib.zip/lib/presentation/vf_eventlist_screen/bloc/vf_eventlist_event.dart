part of 'vf_eventlist_bloc.dart';

/// Abstract class for all events that can be dispatched from the
///VfHomescreen widget.
///
/// Events must be immutable and implement the [Equatable] interface.
class VfEventListScreenEvent extends Equatable {
  @override
  List<Object?> get props => [];
}

class LoadUpcomingEventListEvent extends VfEventListScreenEvent {}

/// Event that is dispatched when the VfHomescreen widget is first created.
class EventListScreenInitialEvent extends VfEventListScreenEvent {
  final String? userId;
  final String? role;
  EventListScreenInitialEvent({this.userId, this.role});

  @override
  List<Object?> get props => [userId, role];
}

class LoadUpcomingInterestEventListEvent extends VfEventListScreenEvent {
  final String? userId;

  LoadUpcomingInterestEventListEvent({this.userId});

  @override
  List<Object?> get props => [userId];
}
