part of 'vf_eventlist_bloc.dart';

/// Represents the state of VfHomescreen in the application.
class VfEventListScreenState extends Equatable {
  final VfEventListModel? vfEventListModelObj;
  final bool isLoading; // To manage loading state
  final List<Voluevents>? upcomingEventsList;
  final String? errorMessage; // Added field for error messages

  const VfEventListScreenState({
    this.vfEventListModelObj,
    this.isLoading = false,
    this.upcomingEventsList,
    this.errorMessage, // Initialize errorMessage
  });

  @override
  List<Object?> get props => [
        vfEventListModelObj,
        isLoading,
        upcomingEventsList,
        errorMessage, // Add to props for equality checks
      ];

  VfEventListScreenState copyWith({
    VfEventListModel? vfEventListModelObj,
    bool? isLoading,
    List<Voluevents>? upcomingEventsList,
    String? errorMessage, // Added parameter for errorMessage
  }) {
    return VfEventListScreenState(
      vfEventListModelObj: vfEventListModelObj ?? this.vfEventListModelObj,
      isLoading: isLoading ?? this.isLoading,
      upcomingEventsList: upcomingEventsList ?? this.upcomingEventsList,
      errorMessage: errorMessage ?? this.errorMessage, // Handle errorMessage
    );
  }
}
