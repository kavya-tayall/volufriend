import 'package:flutter/material.dart';
import 'package:dotted_border/dotted_border.dart';
import 'package:flutter_bloc/flutter_bloc.dart'; // Added import
import 'package:volufriend/auth/bloc/org_event_bloc.dart';
import '../../core/app_export.dart';
import '../../widgets/custom_icon_button.dart';
import 'bloc/vf_homescreen_bloc.dart';
import 'models/actionbuttons_item_model.dart';
import 'models/upcomingeventslist_item_model.dart';
import 'models/vf_homescreen_model.dart';
import 'widgets/actionbuttons_item_widget.dart';
import 'widgets/upcomingeventslist_item_widget.dart';
import 'widgets/volunteergoalhours_graph_widget.dart';
import 'widgets/vf_searchscreen_page.dart';
import 'widgets/todayevent_item_widget.dart';
import '/crud_repository/volufriend_crud_repo.dart';
import '../../auth/bloc/login_user_bloc.dart';
import '../vf_homescreen_container_screen/bloc/vf_homescreen_container_bloc.dart';
import 'package:volufriend/presentation/vf_createeventscreen2_eventshifts_screen/bloc/vf_createeventscreen2_eventshifts_bloc.dart';
import 'package:volufriend/presentation/vf_createeventscreen1_eventdetails_screen/bloc/vf_createeventscreen1_eventdetails_bloc.dart';
import 'package:volufriend/presentation/vf_createeventscreen3_eventadditionaldetails_screen/bloc/vf_createeventscreen3_eventadditionaldetails_bloc.dart';

class VfHomescreenPage extends StatelessWidget {
  const VfHomescreenPage({Key? key}) : super(key: key);

  static Widget builder(BuildContext context) {
    final String userRole = getUserRole(context);
    final String userId = getUserId(context);

    context
        .read<VfHomescreenBloc>()
        .add(VfHomescreenInitialEvent(userId: userId, role: userRole));
    context.read<orgVoluEventBloc>().add(resetEvent());
    return const VfHomescreenPage();
  }

  @override
  Widget build(BuildContext context) {
    // Assume you are fetching the user role from your login state
    final String userRole = getUserRole(context);

    Voluevents fetchTodayEvent() {
      return Voluevents(
        eventId: 'event123',
        orgUserId: 'orgUser456',
        address: '123 Main St, Springfield',
        causeId: 'cause789',
        coordinator: Coordinator(
            name: 'John Doe', email: "abc@gmail.com", phone: '123-456-7890'),
        createdAt: DateTime.now().subtract(Duration(days: 10)),
        createdBy: 'admin',
        description: 'A community event to help clean the park.',
        endDate: DateTime.now().add(Duration(days: 1)),
        eventAlbum: 'album123',
        eventStatus: 'Active',
        eventWebsite: 'https://example.com/event',
        location: 'Springfield Park',
        title: 'Park Cleanup',
        orgId: 'org123',
        startDate: DateTime.now(),
        regByDate: DateTime.now().subtract(Duration(days: 1)),
        updatedAt: DateTime.now(),
        updatedBy: 'admin',
        EventHostingType: ['In-Person'],
        orgName: 'Springfield Volunteers',
        shifts: [
          Shift(
            shiftId: 'shift123',
            eventId: 'event123',
            activity: 'Morning Shift',
            startTime: DateTime.now(),
            endTime: DateTime.now().add(Duration(hours: 4)),
            maxNumberOfParticipants: 10,
          ),
        ],
      );
    }

    // Assume you are fetching the today event from some API or Bloc state
    final Voluevents todayEvent =
        fetchTodayEvent(); // Replace with your event fetching logic

    return Scaffold(
      backgroundColor: Colors.transparent,
      body: SingleChildScrollView(
        child: Padding(
          padding: EdgeInsets.symmetric(horizontal: 16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Add the Search Bar at the top
              GestureDetector(
                onTap: () {
                  // Show SearchPage as a bottom sheet
                  showModalBottomSheet(
                    context: context,
                    isScrollControlled: true,
                    backgroundColor: Colors.transparent,
                    builder: (context) => SearchPage(
                      socialCauses: [],
                      allEvents: [],
                      onEventTap: (event) {
                        // Handle the event tap action here
                        print("Tapped event: ${event['name']}");
                        Navigator.pop(context); // Dismiss the bottom sheet
                        // You can navigate to a new page or perform any action with the event details
                      },
                    ), // The SearchPage widget
                  );
                },
                child: Container(
                  padding: EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                  decoration: BoxDecoration(
                    border: Border.all(color: Colors.grey),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text("Search events, causes, organizations..."),
                      Icon(Icons.search),
                    ],
                  ),
                ),
              ),
              SizedBox(height: 16), // Adjust spacing after search bar

              // Add the compact event notification widget (only if event is present)
              if (todayEvent != null) TodayEventWidget(event: todayEvent),

              SizedBox(height: 16), // Adjust spacing after event notification

              Container(
                width: double.infinity,
                decoration: AppDecoration.fillBlueGray,
                child: Column(
                  children: [
                    Container(
                      width: double.infinity,
                      decoration: AppDecoration.fillGray,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          // Goal Progress
                          GoalProgressWidget(
                            completedHours: 200, // Replace with backend data
                            goalHours: 1000, // Replace with backend data
                          ),
                          SizedBox(
                              height: 40
                                  .h), // Adjusted spacing for a more balanced look

                          // Header Text with Padding
                          Padding(
                            padding: EdgeInsets.symmetric(horizontal: 12.0),
                            child: Text(
                              userRole == 'Volunteer'
                                  ? "Events you might be interested in"
                                  : "Upcoming Events",
                              style: CustomTextStyles.titleMediumGray90003
                                  .copyWith(
                                fontSize: 18.0,
                              ),
                            ),
                          ),
                          SizedBox(
                              height: 24.h), // Adjust spacing between sections

                          // Conditionally render event list
                          userRole == 'Volunteer'
                              ? _buildVolunteerIntrestedEvents(context)
                              : _buildOrgUpcomingEventsList(context),

                          SizedBox(height: 16.h), // Moderate spacing

                          // "Show All" Button
                          Align(
                            alignment: Alignment.centerRight,
                            child: Padding(
                              padding: EdgeInsets.only(
                                  right:
                                      16.0), // Unified padding for consistency
                              child: GestureDetector(
                                onTap: () {
                                  NavigatorService.pushNamed(
                                      AppRoutes.vfEventListScreen);
                                },
                                child: Text(
                                  "Show All", // Use a localized string if necessary
                                  style: CustomTextStyles.titleSmallPrimary_1
                                      .copyWith(
                                    fontSize: 16.0,
                                  ),
                                ),
                              ),
                            ),
                          ),
                          SizedBox(
                              height: 32.h), // Reduce space for a cleaner look

                          // Action Buttons
                          userRole == 'Volunteer'
                              ? _buildVolunteerButton(context)
                              : _buildActionButtonsForOrgProfile(context),
                          SizedBox(
                              height: 40.h), // Final spacing for bottom padding
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

// Helper method to get user role
  static String getUserRole(BuildContext context) {
    // Access the bloc for user role
    final userBloc = BlocProvider.of<UserBloc>(context);
    final userState = userBloc.state;

    if (userState is LoginUserWithHomeOrg) {
      return userState.user.userHomeOrg?.role == "Volunteer"
          ? "Volunteer"
          : "Organization";
    }
    return "";
  }

  static String getUserId(BuildContext context) {
    // Access the bloc for user role

    final userBloc = BlocProvider.of<UserBloc>(context);
    final userState = userBloc.state;
    final userId = userState.userId ?? '';
    return userId;
  }

// Define the Volunteer button builder
  Widget _buildVolunteerButton(BuildContext context) {
    return SizedBox(
      height: 100.h,
      width: 356.h,
      child: BlocListener<orgVoluEventBloc, orgVoluEventState>(
        listener: (context, state) {
          // Handle state changes if needed
          print("I am called");
          if (state.scheduledEvents) {
            // Navigate to VfCreateeventscreen1EventdetailsScreen
            print('Navigating to vfMyupcomingeventscreenScreen ');
            NavigatorService.pushNamed(AppRoutes.vfMyupcomingeventscreenScreen);
          } else if (state.volunteerProfile) {
            // Navigate to VfCreateeventscreen1EventdetailsScreen
            print('Navigating to vfViewvolunteeringprofilescreenScreen');
            NavigatorService.pushNamed(
                AppRoutes.vfViewvolunteeringprofilescreenScreen);
          } else if (state.attendanceReport) {
            // Navigate to VfCreateeventscreen1EventdetailsScreen
            print('Navigating to vfUserattendancereportpageScreen');
            NavigatorService.pushNamed(
                AppRoutes.vfuserattendancereportpageScreen);
          }
        },
        child: BlocSelector<VfHomescreenBloc, VfHomescreenState,
            VfHomescreenModel?>(
          selector: (state) => state.vfHomescreenModelObj,
          builder: (context, vfHomescreenModelObj) {
            if (vfHomescreenModelObj?.actionbuttonsItemList == null ||
                vfHomescreenModelObj!.actionbuttonsItemList.isEmpty) {
              return Center(
                child: Text('No action buttons available'),
              );
            }
            return ListView.separated(
              padding: EdgeInsets.only(
                left: 20.h,
                right: 30.h,
              ),
              scrollDirection: Axis.horizontal,
              separatorBuilder: (context, index) {
                return SizedBox(
                  width: 42.h,
                );
              },
              itemCount: vfHomescreenModelObj.actionbuttonsItemList.length,
              itemBuilder: (context, index) {
                ActionbuttonsItemModel model =
                    vfHomescreenModelObj.actionbuttonsItemList[index];
                return ActionbuttonsItemWidget(model, onPressed: () {
                  print('Tapped on: ${model.text}');
                  if (model.text == 'New opportunities') {
                    // Navigate to VfCreateeventscreen1EventdetailsScreen
                    context
                        .read<orgVoluEventBloc>()
                        .add(findNewOpportunitiesEvent());
                  } else if (model.text == 'View report') {
                    context
                        .read<orgVoluEventBloc>()
                        .add(attendanceReportEvent());
                  } else if (model.text == 'My events') {
                    context
                        .read<orgVoluEventBloc>()
                        .add(scheduledEventsEvent());
                  } else if (model.text == 'Volunteering profile') {
                    final userBloc = BlocProvider.of<UserBloc>(context);
                    final userState = userBloc.state;

                    if (userState is LoginUserWithHomeOrg) {
                      print('User is logged in with home org');
                      final userId = userState.userId!;
                      context
                          .read<orgVoluEventBloc>()
                          .add(volunteerProfileEvent(userId));
                    } else {
                      print('User is not logged in with home org');
                    }
                  } else {
                    // You can add different navigation logic for other buttons here if needed
                  }
                });
              },
            );
          },
        ),
      ),
    );
  }

  Widget _buildVolunteerIntrestedEvents(BuildContext context) {
    return BlocSelector<VfHomescreenBloc, VfHomescreenState,
        VfHomescreenModel?>(
      selector: (state) => state.vfHomescreenModelObj,
      builder: (context, vfHomescreenModelObj) {
        return ListView.builder(
          padding: EdgeInsets.zero,
          physics: const NeverScrollableScrollPhysics(),
          shrinkWrap: true,
          itemCount:
              (vfHomescreenModelObj?.upcomingeventslistItemList.length ?? 0) > 3
                  ? 3
                  : vfHomescreenModelObj?.upcomingeventslistItemList.length ??
                      0,
          itemBuilder: (context, index) {
            UpcomingeventslistItemModel model =
                vfHomescreenModelObj?.upcomingeventslistItemList[index] ??
                    UpcomingeventslistItemModel();
            return UpcomingeventslistItemWidget(
              upcomingeventslistItemModelObj: model,
              onTap: () {
                // Handle on tap action here
                resetEventInitializationFlags(context);

                print('Tapped on: ${model.id}');

                context.read<VfHomescreenBloc>().add(
                      UpcomingEventTappedEvent(eventId: model.id!),
                    );

                context.read<orgVoluEventBloc>().add(UpdateEvent(model.id!));

                final orgEventBloc =
                    BlocProvider.of<VfHomescreenContainerBloc>(context);
                final orgEventState = orgEventBloc.state;
                final eventId = orgEventState.eventId;
                print('Event ID at the time of emmiting: $eventId');

                final orgEventBlocNew =
                    BlocProvider.of<orgVoluEventBloc>(context);
                final orgEventStateNew = orgEventBlocNew.state;
                final eventIdNew = orgEventStateNew.eventId;
                print('New bloc Event ID at the time of emmiting: $eventIdNew');

                NavigatorService.pushNamed(AppRoutes.vfEventsignupscreenScreen);
              },
              onLongPress: () {
                // Handle on long press action here
                print('Long pressed on: ${model.id}');
                // Add long press event handling logic, such as showing a dialog
              },
              onDismissed: () {
                // Handle on swipe action here
                print('Dismissed event: ${model.id}');
                context.read<VfHomescreenBloc>().add(
                      UpcomingEventDismissedEvent(eventId: model.id!),
                    );
              },
            );
          },
        );
      },
    );
  }

  /// Section Widget
  Widget _buildOrgUpcomingEventsList(BuildContext context) {
    return BlocSelector<VfHomescreenBloc, VfHomescreenState,
        VfHomescreenModel?>(
      selector: (state) => state.vfHomescreenModelObj,
      builder: (context, vfHomescreenModelObj) {
        return ListView.builder(
          padding: EdgeInsets.zero,
          physics: const NeverScrollableScrollPhysics(),
          shrinkWrap: true,
          itemCount:
              (vfHomescreenModelObj?.upcomingeventslistItemList.length ?? 0) > 3
                  ? 3
                  : vfHomescreenModelObj?.upcomingeventslistItemList.length ??
                      0,
          itemBuilder: (context, index) {
            UpcomingeventslistItemModel model =
                vfHomescreenModelObj?.upcomingeventslistItemList[index] ??
                    UpcomingeventslistItemModel();
            return UpcomingeventslistItemWidget(
              upcomingeventslistItemModelObj: model,
              onTap: () {
                // Handle on tap action here
                resetEventInitializationFlags(context);

                print('Tapped on: ${model.id}');

                context.read<VfHomescreenBloc>().add(
                      UpcomingEventTappedEvent(eventId: model.id!),
                    );
                context
                    .read<VfHomescreenContainerBloc>()
                    .add(SetEventIdInDetailsViewMode(model.id!));

                context.read<orgVoluEventBloc>().add(UpdateEvent(model.id!));

                final orgEventBloc =
                    BlocProvider.of<VfHomescreenContainerBloc>(context);
                final orgEventState = orgEventBloc.state;
                final eventId = orgEventState.eventId;
                print('Event ID at the time of emmiting: $eventId');

                final orgEventBlocNew =
                    BlocProvider.of<orgVoluEventBloc>(context);
                final orgEventStateNew = orgEventBlocNew.state;
                final eventIdNew = orgEventStateNew.eventId;
                print('New bloc Event ID at the time of emmiting: $eventIdNew');

                NavigatorService.pushNamed(
                    AppRoutes.vfCreateeventscreen1EventdetailsScreen);
              },
              onLongPress: () {
                // Handle on long press action here
                print('Long pressed on: ${model.id}');
                // Add long press event handling logic, such as showing a dialog
              },
              onDismissed: () {
                // Handle on swipe action here
                print('Dismissed event: ${model.id}');
                context.read<VfHomescreenBloc>().add(
                      UpcomingEventDismissedEvent(eventId: model.id!),
                    );
              },
            );
          },
        );
      },
    );
  }

  void resetEventInitializationFlags(BuildContext context) {
    // Access the bloc for VfCreateeventscreen1EventdetailsBloc
    print('Resetting event initialization flags');
    final eventDetailsBloc1 =
        BlocProvider.of<VfCreateeventscreen1EventdetailsBloc>(context);
    // Emit state with isInitialized set to false
    eventDetailsBloc1
        .add(VfCreateeventscreen1EventdetailsResetInitializationEvent());

    // Access the bloc for VfCreateeventscreen2EventdetailsBloc
    final eventDetailsBloc2 =
        BlocProvider.of<VfCreateeventscreen2EventshiftsBloc>(context);
    // Emit state with isInitialized set to false
    eventDetailsBloc2.add(VfCreateeventscreen2ShiftsResetInitializationEvent());

    // Access the bloc for VfCreateeventscreen3EventadditionaldetailsBloc
    final eventDetailsBloc3 =
        BlocProvider.of<VfCreateeventscreen3EventadditionaldetailsBloc>(
            context);
    // Emit state with isInitialized set to false
    eventDetailsBloc3.add(
        VfCreateeventscreen3EventadditionaldetailsResetInitializationEvent());
  }

  /// Section Widget
  Widget _buildActionButtonsForOrgProfile(BuildContext context) {
    return SizedBox(
      height: 100.h,
      width: 356.h,
      child: BlocListener<orgVoluEventBloc, orgVoluEventState>(
        listener: (context, state) {
          // Handle state changes if needed
          print("I am called");
          if (state.isLoading) {
            resetEventInitializationFlags(context);
            // Navigate to VfCreateeventscreen1EventdetailsScreen
            print(
                'Navigating to VfCreateeventscreen1EventdetailsScreen for create');
            NavigatorService.pushNamed(
                AppRoutes.vfCreateeventscreen1EventdetailsScreen);
          }
        },
        child: BlocSelector<VfHomescreenBloc, VfHomescreenState,
            VfHomescreenModel?>(
          selector: (state) => state.vfHomescreenModelObj,
          builder: (context, vfHomescreenModelObj) {
            if (vfHomescreenModelObj?.actionbuttonsItemList == null ||
                vfHomescreenModelObj!.actionbuttonsItemList.isEmpty) {
              return Center(
                child: Text('No action buttons available'),
              );
            }
            return ListView.separated(
              padding: EdgeInsets.only(
                left: 20.h,
                right: 30.h,
              ),
              scrollDirection: Axis.horizontal,
              separatorBuilder: (context, index) {
                return SizedBox(
                  width: 42.h,
                );
              },
              itemCount: vfHomescreenModelObj.actionbuttonsItemList.length,
              itemBuilder: (context, index) {
                ActionbuttonsItemModel model =
                    vfHomescreenModelObj.actionbuttonsItemList[index];
                return ActionbuttonsItemWidget(model, onPressed: () {
                  print('Tapped on: ${model.text}');
                  if (model.text == 'Create Event') {
                    // Navigate to VfCreateeventscreen1EventdetailsScreen
                    context.read<orgVoluEventBloc>().add(CreateEvent());
                  } else {
                    // You can add different navigation logic for other buttons here if needed
                  }
                });
              },
            );
          },
        ),
      ),
    );
  }
}
