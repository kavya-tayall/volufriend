import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:table_calendar/table_calendar.dart';
import 'package:volufriend/crud_repository/volufriend_crud_repo.dart';
import 'bloc/vf_volunteeringcalendarpage_bloc.dart';
import 'models/vf_volunteeringcalendarpage_model.dart';
import '../../auth/bloc/login_user_bloc.dart';

class VfVolunteeringcalendarpageScreen extends StatelessWidget {
  const VfVolunteeringcalendarpageScreen({Key? key}) : super(key: key);

  static Widget builder(BuildContext context) {
    return BlocProvider(
      create: (_) => VfVolunteeringcalendarpageBloc(
        vfCrudService: context.read<VolufriendCrudService>(),
      )..add(InitializeCalendarEvent(
          userId: context.read<UserBloc>().state.userId!, // Pass correct userId
          currentDate: DateTime.now(),
        )),
      child: const VfVolunteeringcalendarpageScreenContent(),
    );
  }

  @override
  Widget build(BuildContext context) {
    return const VfVolunteeringcalendarpageScreenContent();
  }
}

class VfVolunteeringcalendarpageScreenContent extends StatelessWidget {
  const VfVolunteeringcalendarpageScreenContent({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Volunteering Calendar'),
      ),
      body: Column(
        children: [
          BlocBuilder<VfVolunteeringcalendarpageBloc,
              VfVolunteeringcalendarpageState>(
            builder: (context, state) {
              return TableCalendar<Voluevents>(
                firstDay: DateTime.now(), // Start calendar from today
                lastDay: DateTime.now().add(const Duration(
                    days: 60)), // Restrict to two months from today
                focusedDay: state.focusedDay,
                selectedDayPredicate: (day) =>
                    isSameDay(state.selectedDay, day),
                calendarFormat: state.calendarFormat,
                // Use the _eventsCache from the state directly instead of selectedEvents
                eventLoader: (day) => context
                    .read<VfVolunteeringcalendarpageBloc>()
                    .getEventsForDayFromCache(day),
                startingDayOfWeek: StartingDayOfWeek.monday,
                calendarStyle: const CalendarStyle(
                  outsideDaysVisible: false,
                ),
                onDaySelected: (selectedDay, focusedDay) {
                  // Explicitly fetch events for the day or set an empty list if no events
                  context.read<VfVolunteeringcalendarpageBloc>().add(
                      SelectDayEvent(selectedDay, focusedDay,
                          context.read<UserBloc>().state.userId!));
                },
                onFormatChanged: (format) {
                  context
                      .read<VfVolunteeringcalendarpageBloc>()
                      .add(ChangeCalendarFormatEvent(format));
                },
                onPageChanged: (focusedDay) {
                  context.read<VfVolunteeringcalendarpageBloc>().add(
                      InitializeCalendarEvent(
                          userId: context.read<UserBloc>().state.userId!,
                          currentDate: focusedDay));
                },
              );
            },
          ),
          const SizedBox(height: 8.0),
          Expanded(
            child: BlocBuilder<VfVolunteeringcalendarpageBloc,
                VfVolunteeringcalendarpageState>(
              builder: (context, state) {
                // Fetch events for the selected day from the cache directly
                final selectedDayEvents = context
                    .read<VfVolunteeringcalendarpageBloc>()
                    .getEventsForDayFromCache(state.selectedDay);

                // If no events on the selected day, show a message or empty list
                if (selectedDayEvents.isEmpty) {
                  return const Center(
                    child: Text('No events for the selected day.'),
                  );
                }

                return ListView.builder(
                  itemCount: selectedDayEvents.length,
                  itemBuilder: (context, index) {
                    return Container(
                      margin: const EdgeInsets.symmetric(
                        horizontal: 12.0,
                        vertical: 4.0,
                      ),
                      decoration: BoxDecoration(
                        border: Border.all(),
                        borderRadius: BorderRadius.circular(12.0),
                      ),
                      child: ListTile(
                        onTap: () => print('${selectedDayEvents[index].title}'),
                        title: Text('${selectedDayEvents[index].title}'),
                      ),
                    );
                  },
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
