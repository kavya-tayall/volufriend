import 'package:equatable/equatable.dart';
import 'package:flutter/foundation.dart';

@immutable
class Attendance extends Equatable {
  final String userId;
  final String username; // Assuming 'username' is part of the JSON.
  final String organizationName;
  final String eventId;
  final String eventDate;
  final String eventName;
  final String shiftId;
  final String shiftName;
  final String coordinatorName;
  final String coordinatorEmail;
  final int hoursAttended;
  final int hoursApproved;
  final int hoursRejected;

  Attendance({
    required this.userId,
    required this.username,
    required this.organizationName,
    required this.eventId,
    required this.eventDate,
    required this.eventName,
    required this.shiftId,
    required this.shiftName,
    required this.coordinatorName,
    required this.coordinatorEmail,
    required this.hoursAttended,
    required this.hoursApproved,
    required this.hoursRejected,
  });

  factory Attendance.fromJson(
      Map<String, dynamic> json, String userId, String username) {
    return Attendance(
      userId: userId as String? ?? '', // Default to an empty string if null
      username: username as String? ?? '', // Default to an empty string if null
      organizationName: json['organization_name'] as String? ??
          '', // Default to an empty string if null
      eventId: json['event_id'] as String? ??
          '', // Default to an empty string if null
      eventDate: json['event_date'] as String? ??
          '', // Default to an empty string if null
      eventName: json['event_name'] as String? ??
          '', // Default to an empty string if null
      shiftId: json['shift_id'] as String? ??
          '', // Default to an empty string if null
      shiftName: json['shift_name'] as String? ??
          '', // Default to an empty string if null
      coordinatorName: json['coordinator_name'] as String? ??
          '', // Default to an empty string if null
      coordinatorEmail: json['coordinator_email'] as String? ??
          '', // Default to an empty string if null
      hoursAttended:
          json['hours_attended'] as int? ?? 0, // Default to 0 if null
      hoursApproved:
          json['hours_approved'] as int? ?? 0, // Default to 0 if null
      hoursRejected:
          json['hours_rejected'] as int? ?? 0, // Default to 0 if null
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'user_id': userId,
      'username': username, // Include username in JSON output
      'organization_name': organizationName,
      'event_id': eventId,
      'event_date': eventDate,
      'event_name': eventName,
      'shift_id': shiftId,
      'shift_name': shiftName,
      'coordinator_name': coordinatorName,
      'coordinator_email': coordinatorEmail,
      'hours_attended': hoursAttended,
      'hours_approved': hoursApproved,
      'hours_rejected': hoursRejected,
    };
  }

  @override
  List<Object?> get props => [
        userId,
        username,
        organizationName,
        eventId,
        eventDate,
        eventName,
        shiftId,
        shiftName,
        coordinatorName,
        coordinatorEmail,
        hoursAttended,
        hoursApproved,
        hoursRejected,
      ];

  // Method to extract attendance records from JSON
  static List<Attendance> fromJsonList(
      Map<String, dynamic> json, String userId) {
    List<Attendance> attendanceList = [];

    json.forEach((key, value) {
      String username = json['volunteer_name'] as String? ?? ''; //
      if (value is Map<String, dynamic> && value['attendances'] != null) {
        // Ensure that attendances is a Map
        if (value['attendances'] is Map<String, dynamic>) {
          value['attendances'].forEach((attendanceKey, attendanceValue) {
            if (attendanceValue is Map<String, dynamic>) {
              attendanceList
                  .add(Attendance.fromJson(attendanceValue, userId, username));
            } else {
              print(
                  'Invalid attendance data for key: $attendanceKey, value: $attendanceValue');
            }
          });
        } else {
          print('Invalid attendances data for key: $key, expected a Map');
        }
      } else {
        print('No attendances found for key: $key or value is not a Map');
      }
    });

    return attendanceList;
  }
}

@immutable
class Volunteer extends Equatable {
  final String volunteerId;
  final String userId;
  final String volunteerName;
  final String firstName;
  final String lastName;
  final Map<String, Attendance> attendances;

  Volunteer({
    required this.volunteerId,
    required this.userId,
    required this.volunteerName,
    required this.firstName,
    required this.lastName,
    required this.attendances,
  });

  factory Volunteer.fromJson(Map<String, dynamic> json, String volunteerId) {
    Map<String, Attendance> attendances = {};
    if (json['attendances'] != null) {
      json['attendances'].forEach((key, value) {
        attendances[key] = Attendance.fromJson(
            value, json['user_id'] as String, json['volunteer_name'] as String);
      });
    }
    return Volunteer(
      volunteerId: volunteerId,
      userId: json['user_id'] as String,
      volunteerName: json['volunteer_name'] as String,
      firstName: json['First Name'] as String,
      lastName: json['Last Name'] as String,
      attendances: attendances,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'user_id': userId,
      'volunteer_name': volunteerName,
      'First Name': firstName,
      'Last Name': lastName,
      'attendances':
          attendances.map((key, value) => MapEntry(key, value.toJson())),
    };
  }

  @override
  List<Object?> get props => [
        volunteerId,
        userId,
        volunteerName,
        firstName,
        lastName,
        attendances,
      ];
}
