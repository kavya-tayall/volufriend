part of 'org_event_bloc.dart';

class orgVoluEventState extends Equatable {
  final String eventId;
  final String userId;
  final bool isLoading;
  final bool findNewOpportunities; // CamelCase adjustment
  final bool scheduledEvents; // CamelCase adjustment
  final bool volunteerProfile; // CamelCase adjustment
  final bool attendanceReport;

  orgVoluEventState({
    this.eventId = '',
    this.userId = '',
    this.isLoading = false,
    this.findNewOpportunities = false, // Proper field initialization
    this.scheduledEvents = false, // Proper field initialization
    this.volunteerProfile = false, // Proper field initialization
    this.attendanceReport = false,
  });

  orgVoluEventState copyWith({
    String? eventId,
    String? userId,
    bool? isLoading,
    bool? findNewOpportunities, // Adjusted name to match the field
    bool? scheduledEvents, // Adjusted name to match the field
    bool? volunteerProfile, // Adjusted name to match the field
    bool? attendanceReport,
  }) {
    return orgVoluEventState(
      eventId: eventId ?? this.eventId,
      userId: userId ?? this.userId,
      isLoading: isLoading ?? this.isLoading,
      findNewOpportunities: findNewOpportunities ?? this.findNewOpportunities,
      scheduledEvents: scheduledEvents ?? this.scheduledEvents,
      volunteerProfile: volunteerProfile ?? this.volunteerProfile,
      attendanceReport: attendanceReport ?? this.attendanceReport,
    );
  }

  @override
  List<Object> get props => [
        eventId,
        userId,
        isLoading,
        findNewOpportunities,
        scheduledEvents,
        volunteerProfile,
        attendanceReport,
      ];
}
