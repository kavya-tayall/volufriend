import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_bloc_project/crud/get_user/bloc/bloc.dart';
import 'package:flutter_bloc_project/crud/get_users/bloc/bloc.dart';
import 'view.dart';

class HomePage extends StatelessWidget {
  const HomePage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      drawer: const SideDrawer(),
      appBar: AppBar(
        title: const Text("Users"),
      ),
      body: const SafeArea(
        child: Column(
          children: [
            Expanded(child: UserList()), // Display the list of users
          ],
        ),
      ),
    );
  }
}

class UserList extends StatelessWidget {
  const UserList({super.key});

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<GetUsersBloc, GetUsersState>(
      builder: (context, state) {
        if (state is GetUsersLoading) {
          return const Center(child: CircularProgressIndicator());
        } else if (state is GetUsersLoaded) {
          if (state.users.isEmpty) {
            return const Center(child: Text('No users found'));
          }
          return ListView.builder(
            itemCount: state.users.length,
            itemBuilder: (context, index) {
              final user = state.users[index];
              return ListTile(
                leading: ClipRRect(
                  borderRadius: BorderRadius.circular(50),
                  child: Image.network(
                    user.pictureUrl ??
                        'https://via.placeholder.com/150', // Placeholder image for null avatars
                    width: 50,
                    height: 50,
                    fit: BoxFit.cover,
                    errorBuilder: (context, error, stackTrace) =>
                        const Icon(Icons.error),
                  ),
                ),
                title: Text(
                    '${user.firstName ?? 'Unknown'} ${user.lastName ?? 'User'}'),
                subtitle: Text(user.email ?? 'No email available'),
                onTap: () {
                  // Trigger GetUser event with the selected user ID
                  BlocProvider.of<GetUserBloc>(context).add(GetUser(user.id));

                  // Show dialog with user details
                  showDialog(
                    context: context,
                    builder: (context) => const UserDetailDialog(),
                  );
                },
              );
            },
          );
        } else if (state is GetUsersError) {
          return const Center(child: Text('Something went wrong!'));
        } else {
          return const Center(child: Text('Unknown state'));
        }
      },
    );
  }
}

class UserDetailDialog extends StatelessWidget {
  const UserDetailDialog({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: const Text('User Details'),
      content: BlocBuilder<GetUserBloc, GetUserState>(
        builder: (context, state) {
          if (state is GetUserLoading) {
            return const Center(child: CircularProgressIndicator());
          } else if (state is GetUserLoaded) {
            final user = state.user;
            return Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                ClipRRect(
                  borderRadius: BorderRadius.circular(50),
                  child: Image.network(
                    user.pictureUrl ??
                        'https://via.placeholder.com/150', // Placeholder image for null avatars
                    width: 100,
                    height: 100,
                    fit: BoxFit.cover,
                    errorBuilder: (context, error, stackTrace) =>
                        const Icon(Icons.error),
                  ),
                ),
                const SizedBox(height: 16),
                Text('${user.firstName} ${user.lastName}'),
                Text(user.email ?? 'No email available'),
                // Add more user details here as needed
              ],
            );
          } else if (state is GetUserError) {
            return const Text('Failed to load user details');
          } else {
            return const Text('Unknown state');
          }
        },
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.of(context).pop(),
          child: const Text('Close'),
        ),
      ],
    );
  }
}
