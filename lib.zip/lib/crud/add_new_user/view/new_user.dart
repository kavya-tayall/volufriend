import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_bloc_project/crud/add_new_user/bloc/bloc.dart';

class NewUserWidget extends StatelessWidget {
  const NewUserWidget({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final TextEditingController firstNameController = TextEditingController();
    final TextEditingController lastNameController = TextEditingController();
    final TextEditingController dobController = TextEditingController();
    final TextEditingController emailController = TextEditingController();
    final TextEditingController genderController = TextEditingController();
    final TextEditingController phoneController = TextEditingController();
    final TextEditingController pictureUrlController = TextEditingController();
    final TextEditingController roleController = TextEditingController();

    return Center(
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 20),
        child: BlocBuilder<AddNewUserBloc, AddNewUserState>(
          builder: (context, state) {
            return Column(
              children: [
                const Text(
                  "Create User",
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 20),
                TextField(
                  decoration:
                      const InputDecoration(hintText: 'Enter First Name'),
                  controller: firstNameController,
                ),
                const SizedBox(height: 20),
                TextField(
                  decoration:
                      const InputDecoration(hintText: 'Enter Last Name'),
                  controller: lastNameController,
                ),
                const SizedBox(height: 20),
                TextField(
                  decoration: const InputDecoration(
                      hintText: 'Enter Date of Birth (yyyy-mm-dd)'),
                  controller: dobController,
                ),
                const SizedBox(height: 20),
                TextField(
                  decoration: const InputDecoration(hintText: 'Enter Email'),
                  controller: emailController,
                ),
                const SizedBox(height: 20),
                TextField(
                  decoration: const InputDecoration(hintText: 'Enter Gender'),
                  controller: genderController,
                ),
                const SizedBox(height: 20),
                TextField(
                  decoration: const InputDecoration(hintText: 'Enter Phone'),
                  controller: phoneController,
                ),
                const SizedBox(height: 20),
                TextField(
                  decoration:
                      const InputDecoration(hintText: 'Enter Picture URL'),
                  controller: pictureUrlController,
                ),
                const SizedBox(height: 20),
                TextField(
                  decoration: const InputDecoration(hintText: 'Enter Role'),
                  controller: roleController,
                ),
                const SizedBox(height: 20),
                ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.white,
                  ),
                  onPressed: () {
                    final DateTime dob =
                        DateTime.tryParse(dobController.text) ?? DateTime.now();
                    final DateTime createdAt = DateTime.now();
                    final DateTime updatedAt = DateTime.now();

                    context.read<AddNewUserBloc>().add(AddNewUser(
                          firstName: firstNameController.text,
                          lastName: lastNameController.text,
                          createdAt: createdAt,
                          dob: dob,
                          email: emailController.text,
                          gender: genderController.text,
                          phone: phoneController.text,
                          pictureUrl: pictureUrlController.text,
                          role: roleController.text,
                          updatedAt: updatedAt,
                        ));

                    if (context.mounted) {
                      showDialog(
                        context: context,
                        builder: (context) => NewUserDialog(state: state),
                      );
                    }
                  },
                  child: state is AddNewUserLoading
                      ? const CircularProgressIndicator()
                      : const Text(
                          "Create User",
                          style: TextStyle(color: Colors.black, fontSize: 16),
                        ),
                ),
              ],
            );
          },
        ),
      ),
    );
  }
}

class NewUserDialog extends StatelessWidget {
  const NewUserDialog({
    Key? key,
    required this.state,
  }) : super(key: key);

  final AddNewUserState state;

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<AddNewUserBloc, AddNewUserState>(
      builder: (context, state) {
        if (state is AddNewUserLoaded) {
          return Dialog(
            child: Container(
              decoration: BoxDecoration(
                color: Colors.black38,
                borderRadius: BorderRadius.circular(20),
              ),
              child: Padding(
                padding: const EdgeInsets.all(8.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text('ID: ${state.newUser.id}'),
                    Text('First Name: ${state.newUser.firstName}'),
                    Text('Last Name: ${state.newUser.lastName}'),
                    Text('Date of Birth: ${state.newUser.dob}'),
                    Text('Email: ${state.newUser.email}'),
                    Text('Gender: ${state.newUser.gender}'),
                    Text('Phone: ${state.newUser.phone}'),
                    Text('Picture URL: ${state.newUser.pictureUrl}'),
                    Text('Role: ${state.newUser.role}'),
                    Text('Created at: ${state.newUser.createdAt}'),
                  ],
                ),
              ),
            ),
          );
        } else if (state is AddNewUserFailure) {
          return AlertDialog(
            title: const Text('Error'),
            content: Text(state.error),
            actions: [
              TextButton(
                onPressed: () {
                  Navigator.of(context).pop();
                },
                child: const Text('OK'),
              ),
            ],
          );
        }
        return const SizedBox(); // Empty widget if no dialog state is present
      },
    );
  }
}
