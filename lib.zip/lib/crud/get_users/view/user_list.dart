import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_bloc_project/crud/get_users/bloc/get_users_bloc.dart';

class UserList extends StatelessWidget {
  const UserList({super.key});

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<GetUsersBloc, GetUsersState>(
      builder: (context, state) {
        if (state is GetUsersLoading) {
          return const Center(child: CircularProgressIndicator());
        } else if (state is GetUsersLoaded) {
          if (state.users.isEmpty) {
            return const Center(child: Text('No users found'));
          }
          return ListView.builder(
            itemCount: state.users.length,
            itemBuilder: (context, index) {
              final user = state.users[index];
              return ListTile(
                leading: ClipRRect(
                  borderRadius: BorderRadius.circular(50),
                  child: Image.network(
                    user.pictureUrl ??
                        'default_avatar_url', // Provide a default URL or handle null
                    errorBuilder: (context, error, stackTrace) =>
                        const Icon(Icons.error),
                  ),
                ),
                title: Text(
                    '${user.firstName ?? 'Unknown'} ${user.lastName ?? 'User'}'),
                subtitle: Text(user.email ?? 'No email available'),
              );
            },
          );
        } else if (state is GetUsersError) {
          return const Center(child: Text('Something went wrong!'));
        } else {
          return const Center(child: Text('Unknown state'));
        }
      },
    );
  }
}
