import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_bloc_project/crud/update_user/bloc/bloc.dart';

// Combined UpdateUserWidget and UpdateUserDialog into a single file

class UpdateUserWidget extends StatelessWidget {
  const UpdateUserWidget({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final TextEditingController idController = TextEditingController();
    final TextEditingController firstNameController = TextEditingController();
    final TextEditingController lastNameController = TextEditingController();
    final TextEditingController dobController = TextEditingController();
    final TextEditingController emailController = TextEditingController();
    final TextEditingController genderController = TextEditingController();
    final TextEditingController phoneController = TextEditingController();
    final TextEditingController pictureUrlController = TextEditingController();
    final TextEditingController roleController = TextEditingController();
    final TextEditingController updatedAtController = TextEditingController();

    return Center(
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 20),
        child: BlocBuilder<UpdateUserBloc, UpdateUserState>(
          builder: (context, state) {
            return Column(
              children: [
                const Text(
                  "Update User",
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 20),
                TextField(
                  decoration: const InputDecoration(hintText: 'Enter ID'),
                  controller: idController,
                ),
                const SizedBox(height: 20),
                TextField(
                  decoration:
                      const InputDecoration(hintText: 'Enter First Name'),
                  controller: firstNameController,
                ),
                const SizedBox(height: 20),
                TextField(
                  decoration:
                      const InputDecoration(hintText: 'Enter Last Name'),
                  controller: lastNameController,
                ),
                const SizedBox(height: 20),
                TextField(
                  decoration:
                      const InputDecoration(hintText: 'Enter Date of Birth'),
                  controller: dobController,
                ),
                const SizedBox(height: 20),
                TextField(
                  decoration: const InputDecoration(hintText: 'Enter Email'),
                  controller: emailController,
                ),
                const SizedBox(height: 20),
                TextField(
                  decoration: const InputDecoration(hintText: 'Enter Gender'),
                  controller: genderController,
                ),
                const SizedBox(height: 20),
                TextField(
                  decoration: const InputDecoration(hintText: 'Enter Phone'),
                  controller: phoneController,
                ),
                const SizedBox(height: 20),
                TextField(
                  decoration:
                      const InputDecoration(hintText: 'Enter Picture URL'),
                  controller: pictureUrlController,
                ),
                const SizedBox(height: 20),
                TextField(
                  decoration: const InputDecoration(hintText: 'Enter Role'),
                  controller: roleController,
                ),
                const SizedBox(height: 20),
                TextField(
                  decoration:
                      const InputDecoration(hintText: 'Enter Updated At'),
                  controller: updatedAtController,
                ),
                const SizedBox(height: 20),
                ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.white,
                  ),
                  onPressed: () {
                    final userData = {
                      'firstName': firstNameController.text,
                      'lastName': lastNameController.text,
                      'dob': dobController.text,
                      'email': emailController.text,
                      'gender': genderController.text,
                      'phone': phoneController.text,
                      'pictureUrl': pictureUrlController.text,
                      'role': roleController.text,
                      'updatedAt': updatedAtController.text,
                    };

                    context.read<UpdateUserBloc>().add(
                          UpdateUser(
                            id: idController.text,
                            firstName: userData['firstName']!,
                            lastName: userData['lastName']!,
                            dob: DateTime.parse(userData['dob']!),
                            email: userData['email']!,
                            gender: userData['gender']!,
                            phone: userData['phone']!,
                            pictureUrl: userData['pictureUrl']!,
                            role: userData['role']!,
                            updatedAt: DateTime.parse(userData['updatedAt']!),
                          ),
                        );

                    if (context.mounted) {
                      showDialog(
                        context: context,
                        builder: (context) => UpdateUserDialog(state: state),
                      );
                    }
                  },
                  child: state is UpdateUserLoading
                      ? const CircularProgressIndicator()
                      : const Text(
                          "Update User",
                          style: TextStyle(color: Colors.black, fontSize: 16),
                        ),
                ),
              ],
            );
          },
        ),
      ),
    );
  }
}

class UpdateUserDialog extends StatelessWidget {
  const UpdateUserDialog({Key? key, required this.state}) : super(key: key);

  final UpdateUserState state;

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<UpdateUserBloc, UpdateUserState>(
      builder: (context, state) {
        if (state is UpdateUserLoaded) {
          return Dialog(
            child: Container(
              decoration: BoxDecoration(
                color: Colors.black38,
                borderRadius: BorderRadius.circular(20),
              ),
              child: Padding(
                padding: const EdgeInsets.all(8.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text('ID: ${state.updatedUser.id}'),
                    Text('First Name: ${state.updatedUser.firstName}'),
                    Text('Last Name: ${state.updatedUser.lastName}'),
                    Text('Date of Birth: ${state.updatedUser.dob}'),
                    Text('Email: ${state.updatedUser.email}'),
                    Text('Gender: ${state.updatedUser.gender}'),
                    Text('Phone: ${state.updatedUser.phone}'),
                    Text('Picture URL: ${state.updatedUser.pictureUrl}'),
                    Text('Role: ${state.updatedUser.role}'),
                    Text('Updated at: ${state.updatedUser.updatedAt}'),
                  ],
                ),
              ),
            ),
          );
        } else if (state is UpdateUserError) {
          return AlertDialog(
            title: const Text('Error'),
            content: Text(state.error),
            actions: [
              TextButton(
                onPressed: () {
                  Navigator.of(context).pop();
                },
                child: const Text('OK'),
              ),
            ],
          );
        }
        return const SizedBox(); // Empty widget if no dialog state is present
      },
    );
  }
}
