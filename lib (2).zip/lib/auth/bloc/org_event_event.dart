part of 'org_event_bloc.dart';

abstract class orgVoluEventEvent extends Equatable {
  @override
  List<Object> get props => [];
}

class CreateEvent extends orgVoluEventEvent {}

class findNewOpportunitiesEvent extends orgVoluEventEvent {}

class scheduledEventsEvent extends orgVoluEventEvent {}

class attendanceReportEvent extends orgVoluEventEvent {}

class volunteerProfileEvent extends orgVoluEventEvent {
  final String userId;

  volunteerProfileEvent(this.userId);

  @override
  List<Object> get props => [userId];
}

class resetEvent extends orgVoluEventEvent {}

class UpdateEvent extends orgVoluEventEvent {
  final String eventId;

  UpdateEvent(this.eventId);

  @override
  List<Object> get props => [eventId];
}
