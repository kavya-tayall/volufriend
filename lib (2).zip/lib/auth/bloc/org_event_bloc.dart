import 'package:equatable/equatable.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

part 'org_event_event.dart';
part 'org_event_state.dart';

class orgVoluEventBloc extends Bloc<orgVoluEventEvent, orgVoluEventState> {
  orgVoluEventBloc() : super(orgVoluEventState()) {
    on<CreateEvent>(_onLoadData);
    on<UpdateEvent>(_onUpdateData);
    on<findNewOpportunitiesEvent>(_onFindNewOpportunities);
    on<scheduledEventsEvent>(_onScheduledEvents);
    on<resetEvent>(_onResetEvent);
    on<volunteerProfileEvent>(_onVolunteerProfile);
    on<attendanceReportEvent>(_onAttendanceReport);
  }

  // Handler for attendanceReport event
  void _onAttendanceReport(
      attendanceReportEvent event, Emitter<orgVoluEventState> emit) {
    print('attendanceReport event received');
    emit(state.copyWith(
        eventId: '',
        userId: '',
        isLoading: false,
        findNewOpportunities: false,
        scheduledEvents: false,
        volunteerProfile: false,
        attendanceReport: true));
    print('attendanceReport updated to: ${state.attendanceReport}');
  }

  // Handler for volunteerProfile event
  void _onVolunteerProfile(
      volunteerProfileEvent event, Emitter<orgVoluEventState> emit) {
    print('volunteerProfile event received');
    emit(state.copyWith(
        eventId: '',
        userId: event.userId,
        isLoading: false,
        findNewOpportunities: false,
        scheduledEvents: false,
        volunteerProfile: true,
        attendanceReport: false));
    print('volunteerProfile updated to: ${state.userId}');
  }

  // Handler for resetEvent event
  void _onResetEvent(resetEvent event, Emitter<orgVoluEventState> emit) {
    print('resetEvent event received');
    emit(state.copyWith(
        eventId: '',
        userId: '',
        isLoading: false,
        findNewOpportunities: false,
        scheduledEvents: false,
        volunteerProfile: false,
        attendanceReport: false));
    print('State reset');
  }

  // Handler for findNewOpportunities event
  void _onFindNewOpportunities(
      findNewOpportunitiesEvent event, Emitter<orgVoluEventState> emit) {
    print('findNewOpportunities event received');
    emit(state.copyWith(
        findNewOpportunities: true,
        scheduledEvents: false,
        isLoading: false,
        eventId: '',
        userId: '',
        volunteerProfile: false,
        attendanceReport: false));
    print('findNewOpportunities updated to: ${state.findNewOpportunities}');
  }

  // Handler for scheduledEvents event
  void _onScheduledEvents(
      scheduledEventsEvent event, Emitter<orgVoluEventState> emit) {
    print('scheduledEvents event received');
    emit(state.copyWith(
      scheduledEvents: true,
      findNewOpportunities: false,
      isLoading: false,
      eventId: '',
      userId: '',
      volunteerProfile: false,
      attendanceReport: false,
    ));
    print('scheduledEvents updated to: ${state.scheduledEvents}');
  }

  // Handler for LoadData event
  void _onLoadData(CreateEvent event, Emitter<orgVoluEventState> emit) async {
    print('LoadData event received');
    emit(state.copyWith(
        eventId: '',
        userId: '',
        isLoading: true,
        findNewOpportunities: false,
        scheduledEvents: false,
        volunteerProfile: false,
        attendanceReport: false));
    await Future.delayed(const Duration(seconds: 2)); // Simulate data loading
    emit(state.copyWith(
        eventId: '',
        userId: '',
        isLoading: false,
        findNewOpportunities: false,
        scheduledEvents: false,
        volunteerProfile: false,
        attendanceReport: false));
    print('Data loaded: ${state.eventId}');
  }

  // Handler for UpdateData event
  void _onUpdateData(UpdateEvent event, Emitter<orgVoluEventState> emit) {
    print('UpdateData event received with data: ${event.eventId}');
    emit(state.copyWith(eventId: event.eventId));
    print('Data updated to: ${state.eventId}');
  }
}
