import 'package:flutter/material.dart';
import '../core/app_export.dart';
import 'package:volufriend/core/utils/LocalStorageService.dart'; // Import your LocalStorageService
import '../core/utils/global.dart';

enum BottomBarEnum { Home, Notifications, Schedule, Stats, Profile }

// ignore_for_file: must_be_immutable
class CustomBottomBar extends StatefulWidget {
  final Function(BottomBarEnum)? onChanged;
  final LocalStorageService?
      localStorageService; // Optional LocalStorageService

  CustomBottomBar({this.onChanged, this.localStorageService});

  @override
  CustomBottomBarState createState() => CustomBottomBarState();
}

// ignore_for_file: must_be_immutable
class CustomBottomBarState extends State<CustomBottomBar> {
  int selectedIndex = 0;

  List<BottomMenuModel> bottomMenuList = [
    BottomMenuModel(
      icon: ImageConstant.imgNavHome,
      activeIcon: ImageConstant.imgNavHome,
      title: "lbl_home".tr,
      type: BottomBarEnum.Home,
    ),
    BottomMenuModel(
      icon: ImageConstant.imgNavNotifications,
      activeIcon: ImageConstant.imgNavNotifications,
      title: "lbl_notifications".tr,
      type: BottomBarEnum.Notifications,
    ),
    BottomMenuModel(
      icon: ImageConstant.imgNavSchedule,
      activeIcon: ImageConstant.imgNavSchedule,
      title: "lbl_schedule".tr,
      type: BottomBarEnum.Schedule,
    ),
    BottomMenuModel(
      icon: ImageConstant.imgNavStats,
      activeIcon: ImageConstant.imgNavStats,
      title: "lbl_stats".tr,
      type: BottomBarEnum.Stats,
    ),
    BottomMenuModel(
      icon: ImageConstant.imgNavProfile,
      activeIcon: ImageConstant.imgNavProfile,
      title: "lbl_profile".tr,
      type: BottomBarEnum.Profile,
    ),
  ];

  // Fetches the unread notifications count
  Future<int> _getUnreadNotificationCount() async {
    final localStorageService =
        widget.localStorageService ?? globalLocalStorageService;

    if (localStorageService != null) {
      final List<Map<String, dynamic>> notifications =
          await localStorageService.getNotificationsFromPrefs();

      // Ensure 'isRead' is properly checked as a boolean
      return notifications.where((notif) => notif['isRead'] == false).length;
    }

    // If the service is null, return 0 unread notifications
    return 0;
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 80.h,
      decoration: BoxDecoration(
        color: theme.colorScheme.primary,
      ),
      child: BottomNavigationBar(
        backgroundColor: Colors.transparent,
        showSelectedLabels: false,
        showUnselectedLabels: false,
        selectedFontSize: 0,
        elevation: 0,
        currentIndex: selectedIndex,
        type: BottomNavigationBarType.fixed,
        items: List.generate(bottomMenuList.length, (index) {
          return BottomNavigationBarItem(
            icon: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Stack(
                  clipBehavior: Clip
                      .none, // Ensures the badge is shown outside the bounds
                  children: [
                    CustomImageView(
                      imagePath: bottomMenuList[index].icon,
                      height: 24.h,
                      width: 24.h,
                      color: appTheme.greenA100,
                    ),
                    if (index == 1) // Assuming index 1 is Notifications
                      FutureBuilder<int>(
                        future: _getUnreadNotificationCount(),
                        builder: (context, snapshot) {
                          if (snapshot.connectionState ==
                              ConnectionState.waiting) {
                            return Container(); // Loading state
                          } else if (snapshot.hasData && snapshot.data! > 0) {
                            return Positioned(
                              right:
                                  -6.0, // Adjust positioning to avoid distortion
                              top:
                                  -6.0, // Badge should overlap properly on the top-right
                              child: Container(
                                padding: EdgeInsets.symmetric(
                                    horizontal: 6.0, vertical: 2.0),
                                decoration: BoxDecoration(
                                  color: Colors.red,
                                  borderRadius: BorderRadius.circular(12),
                                ),
                                child: Text(
                                  snapshot.data!.toString(),
                                  style: TextStyle(
                                    color: Colors.white,
                                    fontSize: 12,
                                  ),
                                ),
                              ),
                            );
                          }
                          return Container();
                        },
                      ),
                  ],
                ),
                Padding(
                  padding: EdgeInsets.only(top: 10.h),
                  child: Text(
                    bottomMenuList[index].title ?? "",
                    style: theme.textTheme.labelLarge!.copyWith(
                      color: appTheme.greenA100,
                    ),
                  ),
                )
              ],
            ),
            activeIcon: SizedBox(
              width: 64.h,
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    width: double.maxFinite,
                    decoration: BoxDecoration(
                      color: appTheme.cyan900,
                      borderRadius: BorderRadius.circular(16.h),
                    ),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        CustomImageView(
                          imagePath: bottomMenuList[index].activeIcon,
                          height: 24.h,
                          width: 24.h,
                          color: appTheme.greenA100,
                          margin: EdgeInsets.fromLTRB(20.h, 4.h, 19.h, 4.h),
                        )
                      ],
                    ),
                  ),
                  Padding(
                    padding: EdgeInsets.only(top: 6.h),
                    child: Text(
                      bottomMenuList[index].title ?? "",
                      style: theme.textTheme.labelLarge!.copyWith(
                        color: appTheme.greenA100,
                      ),
                    ),
                  )
                ],
              ),
            ),
            label: '',
          );
        }),
        onTap: (index) {
          selectedIndex = index;
          widget.onChanged?.call(bottomMenuList[index].type);
          setState(() {});
        },
      ),
    );
  }
}

// ignore_for_file: must_be_immutable
class BottomMenuModel {
  BottomMenuModel({
    required this.icon,
    required this.activeIcon,
    this.title,
    required this.type,
  });

  String icon;
  String activeIcon;
  String? title;
  BottomBarEnum type;
}

class DefaultWidget extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      color: Color(0xffffffff),
      padding: EdgeInsets.all(10),
      child: Center(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              'Please replace the respective Widget here',
              style: TextStyle(
                fontSize: 18,
              ),
            )
          ],
        ),
      ),
    );
  }
}
