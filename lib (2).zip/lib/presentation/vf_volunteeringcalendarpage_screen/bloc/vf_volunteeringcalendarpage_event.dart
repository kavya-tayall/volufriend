part of 'vf_volunteeringcalendarpage_bloc.dart';

abstract class VfVolunteeringcalendarpageEvent extends Equatable {
  const VfVolunteeringcalendarpageEvent();

  @override
  List<Object?> get props => [];
}

class InitializeCalendarEvent extends VfVolunteeringcalendarpageEvent {
  final String userId;
  final DateTime currentDate;

  const InitializeCalendarEvent(
      {required this.userId, required this.currentDate});

  @override
  List<Object?> get props => [userId, currentDate];
}

class SelectDayEvent extends VfVolunteeringcalendarpageEvent {
  final DateTime selectedDay;
  final DateTime focusedDay;
  final String userId;

  const SelectDayEvent(this.selectedDay, this.focusedDay, this.userId);

  @override
  List<Object?> get props => [selectedDay, focusedDay, userId];
}

class ChangeCalendarFormatEvent extends VfVolunteeringcalendarpageEvent {
  final CalendarFormat format;

  const ChangeCalendarFormatEvent(this.format);

  @override
  List<Object?> get props => [format];
}

class FetchMoreEventsEvent extends VfVolunteeringcalendarpageEvent {
  final String userId;
  final DateTime newEndDate;

  const FetchMoreEventsEvent(this.userId, this.newEndDate);

  @override
  List<Object?> get props => [userId, newEndDate];
}
