import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../vf_eventlist_screen/bloc/vf_eventlist_bloc.dart'; // Ensure this bloc is implemented
import '../vf_eventlist_screen/models/vf_eventlist_model.dart'; // Ensure this model is implemented
import '/crud_repository/volufriend_crud_repo.dart';
import '../vf_homescreen_page/widgets/upcomingeventslist_item_widget.dart';
import '../vf_homescreen_page/models/upcomingeventslist_item_model.dart';
import '../../auth/bloc/login_user_bloc.dart';
import 'package:volufriend/auth/bloc/org_event_bloc.dart';
import '../../core/app_export.dart';
import '../../presentation/vf_homescreen_page/widgets/vf_searchscreen_page.dart';
import '../../widgets/vf_event_filter_widget.dart';

class VfEventListScreen extends StatelessWidget {
  const VfEventListScreen({Key? key}) : super(key: key);

  static Widget builder(BuildContext context) {
    final String userRole = getUserRole(context);
    final String userId = getUserId(context);
    final String orgUserId = getOrgUserId(context);
    final String userIdorOrgUserId =
        userRole == 'Volunteer' ? userId : orgUserId;

    // Dispatch the initial event
    context.read<EventListBloc>().add(EventListScreenInitialEvent(
          role: userRole,
          userId: userIdorOrgUserId,
        ));

    return const VfEventListScreen();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () {
            Navigator.of(context).pop();
          },
        ),
        title: Text(
          "Events You Might Be Interested In",
          style: TextStyle(
            fontSize: 20,
            fontWeight: FontWeight.bold,
            color: Colors.white,
          ),
        ),
        backgroundColor: const Color(0XFF0070BB),
        centerTitle: true,
        elevation: 4.0,
        actions: [
          IconButton(
            icon: const Icon(Icons.search, color: Colors.white),
            onPressed: () {
              // Show SearchPage as a bottom sheet
              showModalBottomSheet(
                context: context,
                isScrollControlled: true,
                backgroundColor: Colors.transparent,
                builder: (context) => SearchPage(
                  allEvents:
                      BlocProvider.of<EventListBloc>(context).state.allEvents,
                  socialCauses: [],
                  onEventTap: (event) {
                    // Handle the event tap action here
                    print("Tapped event: ${event['name']}");
                    Navigator.pop(context); // Dismiss the bottom sheet
                    // You can navigate to a new page or perform any action with the event details
                  },
                ),
              );
            },
          ),
          IconButton(
            icon: const Icon(Icons.filter_list, color: Colors.white),
            onPressed: () async {
              final result = await Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => FilterPage(
                    onApplyFilters: (
                        {required DateTimeRange? dateRange,
                        required List<String> daysOfWeek,
                        required String timeOfDay}) {
                      // This won't be needed anymore
                    },
                  ),
                ),
              );

              if (result != null) {
                // Do something with the result, for example:
                String timeOfDay = result['timeOfDay'];
                DateTimeRange? dateRange = result['dateRange'];
                List<String> daysOfWeek = result['daysOfWeek'];
                print('Time of day: $timeOfDay');
                print('Date range: $dateRange');
                print('Days of week: $daysOfWeek');
                // Handle the filters, e.g., apply them to the event list
              }
            },
          ),
        ],
      ),
      body: SingleChildScrollView(
        child: _buildEventList(context),
      ),
    );
  }

  /// Section Widget
  Widget _buildEventList(BuildContext context) {
    return BlocSelector<EventListBloc, VfEventListScreenState,
        VfEventListModel?>(
      selector: (state) => state.vfEventListModelObj,
      builder: (context, vfEventListModelObj) {
        return ListView.builder(
          padding: EdgeInsets.zero,
          physics: const NeverScrollableScrollPhysics(),
          shrinkWrap: true,
          itemCount:
              vfEventListModelObj?.upcomingeventslistItemList.length ?? 0,
          itemBuilder: (context, index) {
            UpcomingeventslistItemModel model =
                vfEventListModelObj?.upcomingeventslistItemList[index] ??
                    UpcomingeventslistItemModel();
            return UpcomingeventslistItemWidget(
              upcomingeventslistItemModelObj: model,
              onTap: () {
                // Handle on tap action here
                print('Tapped on: ${model.id}');

                context.read<orgVoluEventBloc>().add(UpdateEvent(model.id!));

                final orgEventBloc = BlocProvider.of<orgVoluEventBloc>(context);
                final orgEventState = orgEventBloc.state;
                final eventId = orgEventState.eventId;
                print('Event ID at the time of emmiting: $eventId');

                NavigatorService.pushNamed(AppRoutes.vfEventsignupscreenScreen);
              },
              onLongPress: () {
                // Handle on long press action here
                print('Long pressed on: ${model.id}');
                // Add long press event handling logic, such as showing a dialog
              },
              onDismissed: () {
                // Handle on swipe action here
              },
            );
          },
        );
      },
    );
  }

// Helper method to get user role
  static String getUserRole(BuildContext context) {
    // Access the bloc for user role
    final userBloc = BlocProvider.of<UserBloc>(context);
    final userState = userBloc.state;

    if (userState is LoginUserWithHomeOrg) {
      return userState.user.userHomeOrg?.role == "Volunteer"
          ? "Volunteer"
          : "Organization";
    }
    return "";
  }

  static String getUserId(BuildContext context) {
    // Access the bloc for user role

    final userBloc = BlocProvider.of<UserBloc>(context);
    final userState = userBloc.state;
    final userId = userState.userId ?? '';
    return userId;
  }

  static String getOrgUserId(BuildContext context) {
    // Access the bloc for user role

    final userBloc = BlocProvider.of<UserBloc>(context);
    final userState = userBloc.state;
    if (userState is LoginUserWithHomeOrg) {
      print('User is logged in with home org');
      final userHomeOrg = userState.user.userHomeOrg;
      return userHomeOrg?.useridinorg ?? '';
    }
    return '';
  }
}
